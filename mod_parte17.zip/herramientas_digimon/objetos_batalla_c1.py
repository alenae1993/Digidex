"""Fichas de objetos de batalla Digimon (mismos archivos del mod; las reglas no cambian).

  blast_crystal  -> Chip de Explosión (💥)     choice_band    -> Chip de Fuerza (💪)
  eviolite       -> Cristal de Digievolución (💎)  life_orb   -> Orbe Digital (🔮)
  lucky_egg      -> Trébol de la Suerte (🍀)    star_shield    -> Escudo Estelar (🌟)
  swiftness_sash -> Chip de Velocidad (⚡)
Íconos: Twemoji (CC-BY 4.0), con el mismo disco crema y anillo azul oscuro de las fichas del mod.
Uso: python objetos_batalla_c1.py <carpeta de salida>
"""
import sys

import arte_campana1 as A

ITEMS = {"blast_crystal": "1f4a5", "choice_band": "1f4aa", "eviolite": "1f48e", "life_orb": "1f52e",
         "lucky_egg": "1f340", "star_shield": "1f31f", "swiftness_sash": "26a1"}

if __name__ == "__main__":
    for key, code in ITEMS.items():
        o = A.outline(A.twemoji(code, 560), 9)
        A.save(A.fit(o, 780, 780), f"tokens/item_icons/battle_item_{key}.png")
        A.save(A.on_disk(785, (247, 243, 238), o, ring=(32, 49, 66)), f"tokens/item_tokens/{key}.png")
    print("listo")
