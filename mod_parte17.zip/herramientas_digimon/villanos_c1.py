"""Campaña 1 · La rebelión de Lucemon: agrega al cube las cartas de villanos (como el Equipo Galaxia del mod).

- 8 Soldados Pesadilla (grunt), 6 Señores Demonio con 5 Digimon cada uno (commander) y la corte de Lucemon (boss).
- Igual que en el mod: clima "Space", sin bioma, +2 de vida (h_mod), no capturables, trainer = retrato que va en la carta.
- 10 Digimon nuevos que solo existen como villanos (Barbamon, Daemon, Belphemon RM, etc.): sus stats vienen de un
  Pokémon de referencia (mismo criterio que el resto del cube) y su ataque se agrega a la hoja moves.

Uso: python villanos_c1.py sinnoh_cube.xlsx
Si también usas legendarios_c1.py, córrelo DESPUÉS de este (este borra todo lo que hay bajo los salvajes).
Después hay que abrir y guardar el cube en Excel (o LibreOffice) para recalcular las fórmulas.
"""
import sys
import openpyxl
from openpyxl.worksheet.formula import ArrayFormula

CUBE = sys.argv[1] if len(sys.argv) > 1 else "sinnoh_cube.xlsx"

# Digimon nuevos: nombre, número, elemento, atributo, clasificación, stats (hp, atk, def, spa, spd, spe), Pokémon de referencia,
# ataque (nombre, potencia, efecto) y tipos aprendibles.
NUEVOS = [
    ("Barbamon", 1306, "dark", "virus", "Señor oscuro", (87, 60, 95, 133, 91, 84), "Gholdengo",
     ("Pandemónium Perdido", 105, "Si se obtienen 2 o más símbolos de estado: Inflige el estado Somnoliento al objetivo.")),
    ("Daemon", 1307, "fire", "virus", "Señor oscuro", (95, 135, 80, 110, 80, 100), "Salamence",
     ("Llama del Infierno", 100, "Si se obtienen 2 o más símbolos de estado: Inflige el estado Quemado al objetivo.")),
    ("Belphemon (Rage Mode)", 1308, "dark", "virus", "Señor oscuro", (150, 160, 100, 95, 65, 100), "Slaking",
     ("Cadena de Gehenna", 105, "Los golpes críticos infligen +1 de daño pero los símbolos de estado infligen -1 de daño.")),
    ("Mummymon", 1309, "dark", "virus", "Demonio / Espectro", (58, 50, 145, 95, 105, 30), "Cofagrigus",
     ("Venda Maldita", 85, "Aumenta la fatiga de batalla del objetivo en 2. El objetivo ya no puede cambiar o huir del combate.")),
    ("Darkknightmon", 1310, "dark", "virus", "Caballero oscuro", (65, 125, 100, 60, 70, 70), "Bisharp",
     ("Lanza Oscura", 85, "Los golpes críticos infligen +1 de daño.")),
    ("SkullSatamon", 1311, "dark", "virus", "Demonio / Espectro", (45, 100, 135, 65, 135, 45), "Dusknoir",
     ("Cetro de Nil", 85, "Cuando el objetivo ataque nuevamente, elimina 1 golpe normal de la tirada.")),
    ("NeoDevimon", 1312, "dark", "virus", "Ángel caído", (100, 125, 52, 105, 52, 71), "Honchkrow",
     ("Garra Desgarradora", 85, "Cuando el objetivo sea atacado nuevamente, añade 1 golpe normal a la tirada.")),
    ("Phelesmon", 1313, "dark", "virus", "Demonio / Espectro", (70, 120, 65, 45, 85, 125), "Weavile",
     ("Cadena Negra", 85, "Si se obtienen 1 o más símbolos de estado: tira un dado de estado e Inflige el estado resultante al objetivo.")),
    ("Mephismon", 1314, "dark", "virus", "Demonio / Espectro", (60, 55, 90, 145, 90, 80), "Chandelure",
     ("Gran Tormenta Oscura", 85, "Los símbolos de estado infligen +1 de daño.")),
    ("Lucemon (Satan Mode)", 1315, "dark", "virus", "Señor oscuro", (126, 131, 95, 131, 98, 99), "Yveltal",
     ("Explosión Denna", 105, "Los golpes críticos infligen +2 de daño pero por cada golpe critico obtenido: El usuario recibe 2 de daño.")),
]

# (tier, retrato, descripción en la carta, [Digimon...])
VILLANOS = [
    ("grunt", "soldado_pesadilla_a", "Soldado Pesadilla", ["DemiDevimon", "Tsukaimon", "PetitMamon", "Bakemon"]),
    ("grunt", "soldado_pesadilla_b", "Soldado Pesadilla", ["Soulmon", "Devimon", "IceDevimon", "BlackGatomon"]),
    ("commander", "lilithmon", "Señora Demonio Lilithmon", ["BlackGatomon", "Witchmon", "Arukenimon", "LadyDevimon", "Lilithmon"]),
    ("commander", "barbamon", "Señor Demonio Barbamon", ["Raremon", "Etemon", "Vademon", "Mummymon", "Barbamon"]),
    ("commander", "daemon", "Señor Demonio Daemon", ["Devidramon", "Sangloupmon", "Matadormon", "Myotismon", "Daemon"]),
    ("commander", "leviamon", "Señor Demonio Leviamon", ["Shellmon", "Coelamon", "Orochimon", "MarineDevimon", "Leviamon"]),
    ("commander", "belphemon", "Señor Demonio Belphemon", ["Frigimon", "Hyogamon", "Mammothmon", "SkullMammothmon", "Belphemon (Rage Mode)"]),
    ("commander", "beelzemon", "Señor Demonio Beelzemon", ["Ogremon", "Gururumon", "Tuskmon", "SkullGreymon", "Beelzemon"]),
    ("boss", "lucemon", "Lucemon", ["GranDracmon", "Darkknightmon", "SkullSatamon", "NeoDevimon", "Phelesmon", "Mephismon",
                                    "Lucemon Falldown", "Lucemon (Satan Mode)"]),
]

ELEM_ORDER = ["dark", "neutral", "fire", "wind"]


def main():
    wb = openpyxl.load_workbook(CUBE)
    ws, mv = wb["pokemon"], wb["moves"]
    hdr = [c.value for c in ws[1]]
    col = {h: i + 1 for i, h in enumerate(hdr) if h}
    # columnas repetidas ("total" aparece 2 veces): usar índices fijos
    C = dict(num=1, name=2, hp=5, atk=6, df=7, spa=8, spd=9, spe=10, tot_stats=11, cls=12, biome=13, climate=14, ini_=15,
             hea_=16, imod=17, hmod=18, ini=19, hea=20, tot=21, m1=22, m2=23, m3=24, m4=25, evo=26, evoc=27, iname=28,
             desc=29, mname=30, mtype=31, mstr=32, meff=33, starter=34, legend=35, tier=36, trainer=37, ndeck=38,
             uncap=39, state=40, attr=41, elem=42)
    assert hdr[C["trainer"] - 1] == "trainer" and hdr[C["mname"] - 1] == "move_name" and hdr[C["elem"] - 1] == "element"

    # Limpia una corrida anterior (filas con trainer) y encuentra el final de los Digimon salvajes.
    last = max(r for r in range(2, ws.max_row + 1) if ws.cell(r, C["name"]).value and not ws.cell(r, C["trainer"]).value
               and ws.cell(r, C["tier"]).value != "legendary")
    for r in range(last + 1, ws.max_row + 1):
        for c in range(1, len(hdr) + 1):
            ws.cell(r, c).value = None
    base = {ws.cell(r, C["name"]).value: r for r in range(2, last + 1)}

    # Ataques nuevos en la hoja moves (sin duplicar).
    have = {mv.cell(r, 1).value for r in range(2, mv.max_row + 1)}
    tmpl = mv.max_row
    for n in NUEVOS:
        name, power, effect = n[7]
        if name in have:
            continue
        r = mv.max_row + 1
        mv.cell(r, 1, name); mv.cell(r, 2, n[2]); mv.cell(r, 3, power); mv.cell(r, 5, effect)
        mv.cell(r, 4, f'=IF(NOT(ISBLANK(C{r})), IF(ISNUMBER(C{r}), ROUND((C{r} - 5)/20, 0), C{r}), "")')
        for c in (6, 7, 8):
            src = mv.cell(tmpl, c).value
            src = src.text if hasattr(src, "text") else src
            f = src.replace(f"$A{tmpl}", f"$A{r}")
            mv.cell(r, c).value = ArrayFormula(f"{mv.cell(r, c).coordinate}", f)
        mv.cell(r, 9, f"=H{r}-G{r}")
    nuevos = {n[0]: n for n in NUEVOS}

    r = last + 1
    for tier, trainer, desc, members in VILLANOS:
        for name in members:
            if name in base:
                src = [ws.cell(base[name], c).value for c in range(1, len(hdr) + 1)]
                num, stats, cls = src[0], src[C["hp"] - 1:C["spe"]], src[C["cls"] - 1]
                elem, attr = src[C["elem"] - 1], src[C["attr"] - 1]
                learn = src[C["m1"] - 1:C["m4"]]
                move = f"=VLOOKUP(AB{r},$AB$2:$AD${last},3,FALSE())"
            elif name in nuevos:
                n = nuevos[name]
                num, elem, attr, cls, stats = n[1], n[2], n[3], n[4], n[5]
                learn = [elem] + [e for e in ELEM_ORDER if e != elem][:3]
                move = n[7][0]
            else:
                raise SystemExit(f"Falta el Digimon base: {name}")
            v = {C["num"]: num, C["name"]: name, C["cls"]: cls, C["biome"]: None, C["climate"]: "Space",
                 C["imod"]: 0, C["hmod"]: 2, C["iname"]: name, C["desc"]: desc, C["mname"]: move,
                 C["starter"]: 0, C["legend"]: 0, C["tier"]: tier, C["trainer"]: trainer, C["ndeck"]: 1,
                 C["uncap"]: 1, C["state"]: 0, C["attr"]: attr, C["elem"]: elem}
            for k, s in zip(("hp", "atk", "df", "spa", "spd", "spe"), stats):
                v[C[k]] = s
            for k, t in zip(("m1", "m2", "m3", "m4"), learn):
                v[C[k]] = t
            v[C["tot_stats"]] = f"=SUM(ROUND(S{r},0),ROUND(T{r},0))"
            v[C["ini_"]] = f"=(0.4*J{r} + 0.5*MAX(F{r},H{r}) + 0.1*MIN(F{r},H{r})) / 10"
            v[C["hea_"]] = f"=(0.4*E{r} + 0.3*G{r} + 0.3*I{r}) / 10"
            v[C["ini"]] = f"=ROUND(O{r},0)+Q{r}"
            v[C["hea"]] = f"=ROUND(P{r},0)+R{r}"
            v[C["tot"]] = f"=SUM(ROUND(S{r},0),ROUND(T{r},0))"
            v[C["evoc"]] = f'=IF(ISBLANK(Z{r}), "", ROUND(( (U{r + 1}-6)*(U{r + 1}-7) - (U{r}-6)*(U{r}-7) )/15, 0) + 1)'
            v[C["mtype"]] = f"=VLOOKUP(AD{r},moves!A:B,2,FALSE())"
            v[C["mstr"]] = f"=VLOOKUP(AD{r},moves!A:D,4,FALSE())"
            v[C["meff"]] = f"=VLOOKUP(AD{r},moves!A:E,5,FALSE())"
            for c, val in v.items():
                ws.cell(r, c).value = val
            r += 1
    wb.save(CUBE)
    print(f"Villanos agregados: {r - last - 1} filas (desde la fila {last + 1}). Digimon nuevos: {len(NUEVOS)}.")


if __name__ == "__main__":
    main()
