"""Campaña 1 · La rebelión de Lucemon: agrega al cube las cartas legendarias (los 3 Arcángeles y los legendarios de los santuarios).

Cada legendario Digimon ocupa el lugar de un legendario del mod y COPIA SUS STATS (vida, iniciativa, i_mod, h_mod),
clima, bioma y estado de carta. Así el balance y las reglas del juego quedan exactamente iguales; solo cambian el
Digimon, su elemento y su ataque (con el mismo efecto que el ataque del Pokémon al que reemplaza).

  Dialga / Palkia / Giratina (+ forma Origen) -> Seraphimon / Ophanimon / Cherubimon (+ Forma Pluma / Modo Caído / Forma Vicio)
  Spiritomb -> Alphamon                 Rotom (formas) -> Imperialdramon (Modo Dragón, Luchador, Paladín)
  Celebi -> Omegamon                    Heatran -> Examon               Regigigas -> Huanglongmon
  Cresselia -> Craniummon               Manaphy -> Magnamon             Darkrai -> Duftmon
  Shaymin (+ Cielo) -> Dukemon (+ Modo Carmesí)
  Regirock / Regice / Registeel -> Baihumon / Xuanwumon / Zhuqiaomon
  Articuno / Zapdos / Moltres -> Goddramon / Holydramon / Megidramon (los "Cantos" pasan a ser ataques "Divinos")
  Uxie / Mesprit / Azelf -> AncientGarurumon / AncientWisemon / AncientGreymon
  Silvally -> Susanoomon
No se incluyen las Formas Nobles ni los Ultraentes (son de otras campañas).

Uso: python legendarios_c1.py sinnoh_cube.xlsx    (después abrir y guardar en Excel/LibreOffice para recalcular)
Volver a correrlo reemplaza las filas legendarias anteriores.
"""
import sys
import openpyxl
from openpyxl.worksheet.formula import ArrayFormula

CUBE = sys.argv[1] if len(sys.argv) > 1 else "sinnoh_cube.xlsx"

S_DIV = "Por cada otro Digimon no debilitado de tu equipo con un ataque Divino: La fuerza de ataque aumenta en 1."
S_REP = "Si este ataque se usó el turno anterior, su fuerza de ataque baja a 2."
S_ANC = "Si se obtiene algún símbolo de estado: Inflige el estado {} al objetivo y a otro Digimon del equipo del objetivo."

# nombre, num (imagen), elemento, atributo, clasificación, clima, bioma, descripción, estado de carta,
# stats del Pokémon reemplazado (hp, atk, def, spa, spd, spe), i_mod, h_mod, ataque (nombre, potencia, efecto), aprendibles,
# Pokémon reemplazado (solo referencia)
L = [
    # --- Los 3 Arcángeles (dioses) ---
    ("Seraphimon", 1107, "ligth", "vaccine", "Arcángel", "Space", "Ruins", "Arcángel", 1,
     (100, 120, 120, 150, 100, 90), 0, 0, ("Testamento", 120, S_REP), ("ligth", "wind", "electric", "neutral"), "Dialga"),
    ("Seraphimon", 1107, "ligth", "vaccine", "Arcángel", "Space", "Ruins", "Forma Pluma", 2,
     (100, 120, 120, 150, 100, 90), 0, 1,
     ("Escudo de los Siete Cielos", 80, "Cuando el objetivo ataque nuevamente, los símbolos de estado infligen -2 de daño."),
     ("ligth", "wind", "electric", "neutral"), "Dialga Origen"),
    ("Ophanimon", 1117, "ligth", "vaccine", "Arcángel", "Space", "Ruins", "Arcángel", 1,
     (90, 120, 100, 150, 120, 100), 0, 0, ("Edén", 90, "Los golpes críticos infligen +2 de daño."),
     ("ligth", "wind", "water", "neutral"), "Palkia"),
    ("Ophanimon", 1316, "dark", "virus", "Arcángel", "Space", "Ruins", "Modo Caído", 2,
     (90, 120, 100, 150, 120, 100), -1, 2, ("Sefirot Caído", 120, S_REP), ("dark", "ligth", "water", "wind"), "Palkia Origen"),
    ("Cherubimon", 1089, "ligth", "vaccine", "Arcángel", "Space", "Ruins", "Arcángel", 1,
     (150, 100, 120, 100, 120, 90), 0, 0,
     ("Rayo del Cielo", 100, "El objetivo se debilita si le quedan 2 o menos de vida después de este ataque. Los símbolos de estado infligen -1 de daño."),
     ("ligth", "electric", "wind", "plant"), "Giratina"),
    ("Cherubimon", 1317, "dark", "virus", "Arcángel", "Space", "Ruins", "Forma Vicio", 2,
     (150, 100, 120, 100, 120, 90), 2, -1,
     ("Lanza Relámpago", 100, "Si el objetivo se debilita, el daño que sobra de este ataque se aplica al siguiente Digimon que entre al combate."),
     ("dark", "electric", "wind", "plant"), "Giratina Origen"),
    # --- Legendarios de los santuarios ---
    ("Alphamon", 1014, "ligth", "vaccine", "Caballero Real", "Temperate", "Plains", None, 0,
     (50, 92, 108, 92, 108, 35), 1, 4, ("Alma Digitalizada", 60, "Aumenta la fatiga de batalla del objetivo a 5."),
     ("ligth", "dark", "neutral", "earth"), "Spiritomb"),
    ("Imperialdramon", 1318, "wind", "vaccine", "Dragón Imperial", "Cold", "Forest", None, 1,
     (50, 65, 107, 105, 107, 86), 3, 0,
     ("Mega Láser", 80, "Si el objetivo tiene un objeto equipado, inflige 1 de daño adicional y el estado Paralizado al objetivo."),
     ("wind", "electric", "fire", "neutral"), "Rotom"),
    ("Imperialdramon", 1272, "electric", "vaccine", "Dragón Imperial", "Cold", "Forest", "Modo Luchador", 2,
     (50, 65, 107, 105, 107, 86), 3, 0,
     ("Láser Positrónico Gigante", 100, "Durante este ataque y cuando el usuario sea atacado nuevamente, los símbolos de estado infligen +1 de daño."),
     ("electric", "wind", "fire", "neutral"), "Rotom Calor"),
    ("Imperialdramon", 1319, "ligth", "vaccine", "Dragón Imperial", "Cold", "Forest", "Modo Paladín", 3,
     (50, 65, 107, 105, 107, 86), 3, 0,
     ("Espada Omega", 100, "Si se obtienen 2 o más símbolos de estado: Inflige el estado Confuso al objetivo."),
     ("ligth", "electric", "wind", "neutral"), "Rotom Lavado"),
    ("Omegamon", 1320, "ligth", "vaccine", "Caballero Real", "Temperate", "Forest", None, 0,
     (100, 100, 100, 100, 100, 100), 0, 0,
     ("Espada Gray", 80, "Tus efectos actualmente activos que durarían hasta que el usuario cambie ahora duran hasta el final de la batalla."),
     ("ligth", "fire", "water", "neutral"), "Celebi"),
    ("Examon", 1321, "fire", "data", "Caballero Real", "Warm", "Mountain", None, 0,
     (91, 90, 106, 130, 106, 77), 0, 0,
     ("Gloria de Pendragón", 90, "Inflige el estado Quemado al objetivo. El objetivo ya no puede cambiar o huir del combate."),
     ("fire", "wind", "ligth", "earth"), "Heatran"),
    ("Huanglongmon", 1322, "earth", "vaccine", "Bestia Sagrada", "Cold", "Plains", None, 0,
     (110, 80, 110, 80, 110, 50), 2, 0,
     ("Rugido del Dragón Dorado", 80, "Inflige el estado Paralizado al objetivo. El objetivo ya no puede cambiar o huir del combate."),
     ("earth", "ligth", "electric", "neutral"), "Regigigas"),
    ("Craniummon", 1323, "neutral", "vaccine", "Caballero Real", "Cold", "Forest", None, 0,
     (120, 70, 120, 75, 130, 85), 0, 0,
     ("Avalon", 60, "Cura 3 de daño del usuario. Cuando el usuario sea atacado nuevamente, los símbolos de estado infligen -1 de daño."),
     ("neutral", "ligth", "earth", "wind"), "Cresselia"),
    ("Magnamon", 1324, "ligth", "vaccine", "Caballero Real", "Cold", "Ocean", None, 0,
     (100, 100, 100, 100, 100, 100), 0, 0,
     ("Escudo Milagroso", 100, "Cura todos los efectos de estado del usuario. Cuando el usuario sea atacado nuevamente, elimina 1 golpe normal de la tirada."),
     ("ligth", "water", "electric", "neutral"), "Manaphy"),
    ("Duftmon", 1325, "dark", "data", "Caballero Real", "Cold", "Forest", None, 0,
     (70, 90, 90, 135, 90, 125), -1, 0,
     ("Jaque Mate Real", 60, "Inflige los estados Somnoliento y Paralizado al objetivo al mismo tiempo."),
     ("dark", "wind", "earth", "neutral"), "Darkrai"),
    ("Dukemon", 1326, "ligth", "virus", "Caballero Real", "Warm", "Plains", None, 1,
     (100, 100, 100, 100, 100, 100), 0, 0,
     ("Sable Real", 100, "Si se obtiene algún símbolo de estado: Inflige el estado Quemado al objetivo."),
     ("ligth", "fire", "plant", "neutral"), "Shaymin"),
    ("Dukemon", 1327, "fire", "virus", "Caballero Real", "Warm", "Plains", "Modo Carmesí", 2,
     (100, 103, 75, 120, 75, 127), 0, -1, ("Quo Vadis", 75, "Los golpes críticos infligen +1 de daño."),
     ("fire", "ligth", "wind", "neutral"), "Shaymin Cielo"),
    ("Baihumon", 1328, "earth", "vaccine", "Bestia Sagrada", "Temperate", "Ruins", None, 0,
     (80, 100, 200, 50, 100, 50), -1, 1,
     ("Garra de Acero Sagrado", 60, "Hasta que el usuario cambie: El usuario ahora se cura 2 de daño al final de sus turnos."),
     ("earth", "wind", "ligth", "neutral"), "Regirock"),
    ("Xuanwumon", 1329, "water", "vaccine", "Bestia Sagrada", "Cold", "Ruins", None, 0,
     (80, 50, 100, 100, 200, 50), -1, 1,
     ("Caparazón Glacial", 60, "Hasta que el usuario cambie: Cuando el usuario sea atacado, inflige el estado Congelado al atacante."),
     ("water", "earth", "plant", "neutral"), "Regice"),
    ("Zhuqiaomon", 1330, "fire", "vaccine", "Bestia Sagrada", "Warm", "Ruins", None, 0,
     (80, 75, 150, 75, 150, 50), 0, 1,
     ("Llama Bermellón", 60, "Hasta que el usuario cambie: El usuario es inmune a todos los efectos de estado."),
     ("fire", "wind", "ligth", "neutral"), "Registeel"),
    ("Goddramon", 1331, "ligth", "vaccine", "Dragón Divino", "Cold", "Mountain", None, 0,
     (90, 85, 100, 95, 125, 85), 2, -1, ("Trueno Divino", 100, S_DIV), ("ligth", "electric", "wind", "neutral"), "Articuno"),
    ("Holydramon", 1332, "ligth", "vaccine", "Dragón Divino", "Temperate", "Mountain", None, 0,
     (90, 90, 85, 125, 90, 100), 0, 0, ("Aliento Divino", 100, S_DIV), ("ligth", "fire", "wind", "neutral"), "Zapdos"),
    ("Megidramon", 1333, "fire", "virus", "Dragón Divino", "Warm", "Mountain", None, 0,
     (90, 100, 90, 125, 85, 90), 0, 0, ("Fuego Divino", 100, S_DIV), ("fire", "dark", "wind", "neutral"), "Moltres"),
    ("AncientGarurumon", 1334, "water", "data", "Guerrero Ancestral", "Cold", "Ruins", "Espíritu Ancestral", 0,
     (75, 75, 130, 75, 130, 95), 0, 1, ("Aullido Ancestral", 80, S_ANC.format("Congelado")),
     ("water", "wind", "earth", "neutral"), "Uxie"),
    ("AncientWisemon", 1335, "electric", "data", "Guerrero Ancestral", "Temperate", "Ruins", "Espíritu Ancestral", 0,
     (80, 105, 105, 105, 105, 80), 0, 0, ("Mente Ancestral", 80, S_ANC.format("Paralizado")),
     ("electric", "dark", "ligth", "neutral"), "Mesprit"),
    ("AncientGreymon", 1336, "fire", "vaccine", "Guerrero Ancestral", "Warm", "Ruins", "Espíritu Ancestral", 0,
     (75, 125, 70, 125, 70, 115), 0, 1, ("Corazón Ancestral", 80, S_ANC.format("Quemado")),
     ("fire", "earth", "wind", "neutral"), "Azelf"),
    ("Susanoomon", 1337, "neutral", "vaccine", "Dios / Deidad", "Space", "Ruins", None, 0,
     (95, 95, 95, 95, 95, 95), 0, 0,
     ("Espada Celestial", 90, "Elige cualquier elemento aprendible del usuario como el elemento de este ataque. Ignora los efectos de la Armadura Prisma."),
     ("neutral", "ligth", "fire", "water"), "Silvally"),
]

C = dict(num=1, name=2, hp=5, atk=6, df=7, spa=8, spd=9, spe=10, tot_stats=11, cls=12, biome=13, climate=14, ini_=15,
         hea_=16, imod=17, hmod=18, ini=19, hea=20, tot=21, m1=22, m2=23, m3=24, m4=25, evo=26, evoc=27, iname=28,
         desc=29, mname=30, mtype=31, mstr=32, meff=33, starter=34, legend=35, tier=36, trainer=37, ndeck=38,
         uncap=39, state=40, attr=41, elem=42)


def main():
    wb = openpyxl.load_workbook(CUBE)
    ws, mv = wb["pokemon"], wb["moves"]
    hdr = [c.value for c in ws[1]]
    assert hdr[C["tier"] - 1] == "encounter_tier" and hdr[C["elem"] - 1] == "element"

    # Borra legendarios de una corrida anterior (las filas de abajo suben).
    rows = [r for r in range(2, ws.max_row + 1) if ws.cell(r, C["tier"]).value == "legendary"
            and ws.cell(r, C["climate"]).value != "Noble"]  # las Formas Nobles las maneja nobles_c1.py
    for r in reversed(rows):
        ws.delete_rows(r)
    end = max(r for r in range(1, ws.max_row + 1) if ws.cell(r, C["name"]).value)

    # Ataques nuevos (sin duplicar), con las mismas fórmulas de la hoja moves.
    have = {mv.cell(r, 1).value: r for r in range(2, mv.max_row + 1) if mv.cell(r, 1).value}
    tmpl = max(have.values())
    for x in L:
        name, power, effect = x[12]
        if name in have:
            r = have[name]
        else:
            r = max(have.values()) + 1
            have[name] = r
            for c in (6, 7, 8):
                src = mv.cell(tmpl, c).value
                src = src.text if hasattr(src, "text") else src
                mv.cell(r, c).value = ArrayFormula(mv.cell(r, c).coordinate, src.replace(f"$A{tmpl}", f"$A{r}"))
            mv.cell(r, 4, f'=IF(NOT(ISBLANK(C{r})), IF(ISNUMBER(C{r}), ROUND((C{r} - 5)/20, 0), C{r}), "")')
            mv.cell(r, 9, f"=H{r}-G{r}")
        mv.cell(r, 1, name); mv.cell(r, 2, x[2]); mv.cell(r, 3, power); mv.cell(r, 5, effect)

    r = end + 1
    for (name, num, elem, attr, cls, climate, biome, desc, state, stats, imod, hmod, move, learn, ref) in L:
        v = {C["num"]: num, C["name"]: name, C["cls"]: cls, C["biome"]: biome, C["climate"]: climate,
             C["imod"]: imod, C["hmod"]: hmod, C["iname"]: name, C["desc"]: desc, C["mname"]: move[0],
             C["starter"]: 0, C["legend"]: 1, C["tier"]: "legendary", C["trainer"]: None, C["ndeck"]: 1,
             C["uncap"]: 0, C["state"]: state, C["attr"]: attr, C["elem"]: elem}
        for k, s in zip(("hp", "atk", "df", "spa", "spd", "spe"), stats):
            v[C[k]] = s
        for k, t in zip(("m1", "m2", "m3", "m4"), learn):
            v[C[k]] = t
        v[C["tot_stats"]] = f"=SUM(E{r}:J{r})"
        v[C["ini_"]] = f"=(0.4*J{r} + 0.5*MAX(F{r},H{r}) + 0.1*MIN(F{r},H{r})) / 10"
        v[C["hea_"]] = f"=(0.4*E{r} + 0.3*G{r} + 0.3*I{r}) / 10"
        v[C["ini"]] = f"=ROUND(O{r},0)+Q{r}"
        v[C["hea"]] = f"=ROUND(P{r},0)+R{r}"
        v[C["tot"]] = f"=SUM(ROUND(S{r},0),ROUND(T{r},0))"
        v[C["mtype"]] = f"=VLOOKUP(AD{r},moves!A:B,2,FALSE())"
        v[C["mstr"]] = f"=VLOOKUP(AD{r},moves!A:D,4,FALSE())"
        v[C["meff"]] = f"=VLOOKUP(AD{r},moves!A:E,5,FALSE())"
        for c in range(1, len(hdr) + 1):
            ws.cell(r, c).value = v.get(c)
        r += 1
    wb.save(CUBE)
    print(f"Legendarios agregados: {len(L)} cartas (filas {end + 1}-{r - 1}).")


if __name__ == "__main__":
    main()
