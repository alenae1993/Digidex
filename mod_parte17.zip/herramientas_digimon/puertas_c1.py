"""Fichas de lugar de la campaña 1: las Puertas de los Pecados, la Puerta de Cocytus y el Altar de Yggdrasil.

  tokens/world_tokens/puerta_<pecado>.png   6 puertas (la ficha de lago del mod, teñida con el color de cada pecado)
  tokens/world_tokens/lake_acuity|verity|valor.png  = Lujuria, Codicia, Ira (así las 3 fichas de lago de la mesa ya son puertas)
  tokens/world_tokens/temple_of_sinnoh.png   Puerta de Cocytus (Lucemon)
  tokens/world_tokens/origin_shrine.png      Altar de Yggdrasil (dorado)
La máscara amarilla de "legendario" del mod se conserva.

Uso: python puertas_c1.py <carpeta del mod> <estrella.png> <salida>
"""
import os
import sys

import numpy as np
from PIL import Image, ImageOps

MOD, STAR, OUT = sys.argv[1], sys.argv[2], sys.argv[3]
WT = os.path.join(MOD, "assets/tokens/world_tokens")
PECADOS = [("lujuria", (200, 90, 170)), ("codicia", (220, 180, 60)), ("ira", (210, 70, 60)),
           ("envidia", (60, 120, 200)), ("pereza", (100, 150, 110)), ("gula", (150, 70, 160))]


def tenir(im, dark, light):
    a = np.asarray(im.convert("RGBA")).astype(int)
    r, g, b = a[..., 0], a[..., 1], a[..., 2]
    mask_eye = (r > 200) & (g > 150) & (b < 140)            # la máscara amarilla de legendario
    mask_eye |= (r < 70) & (g < 70) & (b < 80) & (np.abs(r - b) < 25) & False
    t = ImageOps.colorize(ImageOps.grayscale(im.convert("RGB")), dark, light)
    out = np.asarray(t.convert("RGBA")).copy()
    out[..., 3] = a[..., 3]
    eye = ndimage_dilate(mask_eye)
    out[eye] = a[eye]
    return Image.fromarray(out.astype(np.uint8), "RGBA")


def ndimage_dilate(m):
    from scipy import ndimage
    return ndimage.binary_dilation(m, iterations=6) & (ndimage.binary_dilation(m, iterations=6))


def save(im, name):
    p = os.path.join(OUT, "tokens/world_tokens", name)
    os.makedirs(os.path.dirname(p), exist_ok=True)
    im.save(p, optimize=True)


if __name__ == "__main__":
    lago = Image.open(os.path.join(WT, "lake_acuity.png"))
    star = Image.open(STAR).convert("RGBA").resize((200, 200), Image.LANCZOS)
    for i, (sin, col) in enumerate(PECADOS):
        t = tenir(lago, tuple(int(c * 0.25) for c in col), tuple(min(255, int(c * 1.25) + 30) for c in col))
        t.alpha_composite(star, (int(t.width * 0.56), int(t.height * 0.12)))
        save(t, f"puerta_{sin}.png")
        if i < 3:
            save(t, f"lake_{['acuity', 'verity', 'valor'][i]}.png")
    templo = Image.open(os.path.join(WT, "temple_of_sinnoh.png"))
    t = tenir(templo, (25, 20, 45), (200, 215, 255))
    t.alpha_composite(star, (int(t.width * 0.56), int(t.height * 0.12)))
    save(t, "temple_of_sinnoh.png")
    origen = Image.open(os.path.join(WT, "origin_shrine.png"))
    save(tenir(origen, (70, 45, 10), (255, 225, 120)), "origin_shrine.png")
    print("listo")
