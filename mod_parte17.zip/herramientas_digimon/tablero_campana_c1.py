"""Tablero de la campaña 1 (assets/bases/campaigns/base_0.png): textos en español y la estrella de 7 pecados
en lugar del logo del Equipo Galaxia.

Uso: python tablero_campana_c1.py <carpeta del mod> <salida> [estrella.png]
"""
import os
import sys

import numpy as np
from PIL import Image, ImageDraw

MOD, OUT = sys.argv[1], sys.argv[2]
STAR = sys.argv[3] if len(sys.argv) > 3 else os.path.join(MOD, "assets/card_generator/encounter_icons/galactic.png")
sys.argv = [sys.argv[0], MOD, OUT]
import cartas_acto_c1 as T
import cartas_destino_santuario_c1 as C   # inpaint_box

SLOT = (37, 37, 50)
CREAM = (250, 246, 240)


def main():
    im = Image.open(os.path.join(MOD, "assets/bases/campaigns/base_0.png")).convert("RGBA")
    star = Image.open(STAR).convert("RGBA")  # la estrella de 7 puntas de arte_campana1.py
    d = ImageDraw.Draw(im)
    # rótulos de los mazos (sobre la ranura oscura)
    for x0, x1, lines in ((330, 980, ["MAZO DE", "ACTOS"]), (1425, 2225, ["ACTO", "ACTUAL"])):
        cx = (x0 + x1) / 2
        d.rectangle((x0, 880, x1, 1200), fill=im.getpixel((int(cx), 1300))[:3])
        for k, t in enumerate(lines):
            s = 150
            while d.textlength(t, font=T.oriental(s)) > x1 - x0 - 40:
                s -= 6
            d.text((cx, 970 + k * 150), t, font=T.oriental(s), fill=CREAM, anchor="mm")
    # logos del Equipo Galaxia -> estrella de los 7 pecados
    for cx in (2994, 4156, 5327):
        d.ellipse((cx - 370, 1037 - 370, cx + 370, 1037 + 370), fill=SLOT)
        st = star.resize((560, 560), Image.LANCZOS)
        im.alpha_composite(st, (cx - 280, 1037 - 280))
        d.ellipse((cx - 250, 2400 - 250, cx + 250, 2400 + 250), fill=im.getpixel((cx, 2200))[:3])
        st = star.resize((360, 360), Image.LANCZOS)
        im.alpha_composite(st, (cx - 180, 2400 - 180))
        d = ImageDraw.Draw(im)
    # título
    im = C.inpaint_box(im, 5950, 7050, 100, 820, thr=30)
    d = ImageDraw.Draw(im)
    T.spaced(d, "LA", 6500, 150, T.barlow(80), CREAM, 16)
    d.text((6500, 360), "REBELIÓN DE", font=T.oriental(150), fill=CREAM, anchor="mm")
    d.text((6500, 560), "LUCEMON", font=T.oriental(185), fill=CREAM, anchor="mm")
    T.spaced(d, "CAMPAÑA", 6500, 690, T.barlow(80), CREAM, 16)
    # textos de abajo
    im = C.inpaint_box(im, 120, 1200, 2050, 2700, thr=30)
    im = C.inpaint_box(im, 1300, 2350, 2150, 2650, thr=30)
    d = ImageDraw.Draw(im)
    T.draw_para(d, "La campaña JcJ original de Leyendas Digimon", 655, 2130, 104, 950, CREAM, lh=1.22, color=CREAM)
    T.draw_para(d, "Jugadores: 2 – 6\nDuración: 1,5 – 2 horas por jugador", 1825, 2200, 98, 1000, CREAM, lh=1.25, color=CREAM)
    p = os.path.join(OUT, "bases/campaigns/base_0.png")
    os.makedirs(os.path.dirname(p), exist_ok=True)
    im.save(p, optimize=True)
    print("listo")


if __name__ == "__main__":
    main()
