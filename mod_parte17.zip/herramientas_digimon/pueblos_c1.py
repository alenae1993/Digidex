"""Aldeas Digimon de la campaña 1: cartas de pueblo (inicial) y fichas de pueblo del mapa.

  assets/cards/village/card_fronts.png      los 8 pueblos (la 9ª, Ultra Megalópolis, es de otra campaña y no se toca)
  assets/tokens/world_tokens/*_village.png  fichas hexagonales de cada pueblo, con su ícono nuevo
Cada pueblo conserva su color de jugador; cambian el nombre, el ícono, los 2 Digimon iniciales y el texto.

Uso: python pueblos_c1.py <carpeta del mod> <carpeta de imágenes de cartas (assets/card_generator/pokemon)> <salida>
"""
import os
import sys

import numpy as np
from PIL import Image, ImageDraw
from scipy import ndimage

MOD, ART, OUT = sys.argv[1], sys.argv[2], sys.argv[3]
sys.argv = [sys.argv[0], MOD, OUT]
import cartas_acto_c1 as T
import arte_campana1 as A
A.OUT = OUT

W, H = 6336 / 4, 8314 / 3
CREAM = (250, 245, 240)
# archivo de la ficha, nombre nuevo, emoji del ícono, iniciales (número de imagen)
PUEBLOS = [
    ("stark", "Ciudad Factorial", "2699", [("Agumon", 1), ("Guilmon", 38)]),
    ("snowpoint", "Aldea Freezeland", "2744", [("Gabumon", 5), ("Gaomon", 32)]),
    ("sunyshore", "Playa de Coral", "1f41a", [("Terriermon", 1166), ("Veemon", 1160)]),
    ("nesburgh", "Ciudad del Comienzo", "1f95a", [("Shoutmon", 1212), ("Gumdramon", 1164)]),
    ("celestic", "Tierra de Escarabajos", "1fab2", [("Palmon", 62), ("Wormmon", 1176)]),
    ("canalave", "Castillo Geko", "1f438", [("Gomamon", 36)]),
    ("eterna", "Pueblo Juguete", "1f9f8", [("Renamon", 65), ("Coronamon", 1156)]),
    ("sinnome", "Aldea Yokomon", "1f338", [("Patamon", 63), ("Biyomon", 9)]),
]
TEXTO = ("Pon esta carta en tu mano para cambiar el color de tu asiento. Luego vuelve a elegir tu asiento: "
         "el color de tu jugador debe coincidir con el de tu ficha de domador.")


def silueta_blanca(code, size):
    im = A.twemoji(code, size)
    a = im.split()[3]
    out = Image.new("RGBA", im.size, (255, 255, 255, 0))
    out.putalpha(a)
    return out


def hexagono(d, cx, cy, r, **kw):
    import math
    pts = [(cx + r * math.cos(math.pi / 3 * k), cy + r * math.sin(math.pi / 3 * k)) for k in range(6)]
    d.polygon(pts, **kw)


def texto_oscuro(col):
    return 0.299 * col[0] + 0.587 * col[1] + 0.114 * col[2] > 150


def fondo(cell, y0, y1):
    """Rehace el paisaje de la carta sin los Pokémon (bandas tomadas de los bordes)."""
    a = np.asarray(cell).astype(np.float32)
    edge = np.median(np.concatenate([a[y0:y1, 30:110, :], a[y0:y1, 1470:1550, :]], axis=1), axis=1)[:, None, :]
    edge = ndimage.gaussian_filter1d(edge, 6, axis=0)
    x0, x1 = 22, 1562
    band = np.repeat(edge, x1 - x0, axis=1)
    img = Image.fromarray(band.clip(0, 255).astype(np.uint8), "RGBA")
    d = ImageDraw.Draw(img)
    mcol = tuple(int(v) for v in a[(y0 + y1) // 2 - 250, 60, :3])
    pts = [(0, 330), (300, 200), (520, 120), (760, 60), (1000, 140), (1250, 210), (x1 - x0, 300), (x1 - x0, 560), (0, 560)]
    d.polygon(pts, fill=mcol + (255,))
    low = Image.fromarray(band.clip(0, 255).astype(np.uint8), "RGBA").crop((0, 520, x1 - x0, y1 - y0))
    img.paste(low, (0, 520))
    cell.paste(img, (x0, y0))


def cartas():
    sheet = Image.open(os.path.join(MOD, "assets/cards/village/card_fronts.png")).convert("RGBA")
    for i, (key, nombre, icon, starters) in enumerate(PUEBLOS):
        x, y = round((i % 4) * W), round((i // 4) * H)
        cell = sheet.crop((x, y, x + 1584, y + 2771))
        col = cell.getpixel((800, 60))[:3]
        txt = (45, 45, 55) if texto_oscuro(col) else (255, 255, 255)
        d = ImageDraw.Draw(cell)
        d.rectangle((30, 36, 1554, 318), fill=col)                      # encabezado
        hexagono(d, 190, 177, 118, outline=txt, width=12)
        ic = silueta_blanca(icon, 150)
        if txt != (255, 255, 255):
            ic = Image.composite(Image.new("RGBA", ic.size, txt + (255,)), ic, ic.split()[3])
        cell.alpha_composite(ic, (190 - 75, 177 - 75))
        s = 112
        while d.textlength(nombre, font=T.barlow(s)) > 1180:
            s -= 4
        d.text((345, 180), nombre, font=T.barlow(s), fill=txt, anchor="lm")
        fondo(cell, 330, 1585)
        n = len(starters)
        for k, (name, num) in enumerate(starters):
            im = Image.open(os.path.join(ART, f"{num:03}.png")).convert("RGBA")
            im = A.fit(im, 700 if n == 2 else 900, 760 if n == 2 else 900, anchor="bottom")
            cx = 800 if n == 1 else (430 if k == 0 else 1160)
            cell.alpha_composite(im, (int(cx - im.width / 2), 1440 - im.height))
        d = ImageDraw.Draw(cell)
        d.rectangle((30, 1600, 1554, 1855), fill=col)
        d.text((792, 1735), "Elige tu inicial", font=T.barlow(125), fill=txt, anchor="mm")
        d.rounded_rectangle((95, 1975, 1490, 2690), 60, fill=CREAM)
        size = 96
        while T.para_height(d, TEXTO, size, 1260, lh=1.2) > 620:
            size -= 4
        h = T.para_height(d, TEXTO, size, 1260, lh=1.2)
        T.draw_para(d, TEXTO, 792, 2332 - h / 2, size, 1260, (55, 55, 65), lh=1.2, color=(55, 55, 65))
        sheet.paste(cell, (x, y))
    p = os.path.join(OUT, "cards/village/card_fronts.png")
    os.makedirs(os.path.dirname(p), exist_ok=True)
    sheet.save(p, optimize=True)


def fichas():
    for key, nombre, icon, _ in PUEBLOS:
        src = os.path.join(MOD, f"assets/tokens/world_tokens/{key}_village.png")
        if not os.path.exists(src):
            continue
        t = Image.open(src).convert("RGBA")
        a = np.asarray(t).copy()
        inner = ndimage.binary_erosion(a[..., 3] > 200, iterations=40)
        inner[486:] = False                                   # la franja de servicios de abajo queda igual
        px = a[inner][:, :3]
        if key != "snowpoint":
            px = px[px.min(axis=1) < 200]                      # el símbolo es blanco: no cuenta como fondo
        cols, counts = np.unique(px, axis=0, return_counts=True)
        col = cols[counts.argmax()]                           # color de fondo del hexágono
        diff = np.abs(a[..., :3].astype(int) - col).max(axis=2) > 25
        a[inner & diff, :3] = col                              # borra el símbolo de Sinnoh
        t = Image.fromarray(a, "RGBA")
        icol = (150, 150, 160) if col.min() > 200 else (255, 255, 255)
        ic = silueta_blanca(icon, 330)
        ic = Image.composite(Image.new("RGBA", ic.size, icol + (255,)), ic, ic.split()[3])
        t.alpha_composite(ic, (390 - 165, 270 - 175))
        A.save(t, f"tokens/world_tokens/{key}_village.png")


if __name__ == "__main__":
    cartas()
    fichas()
    print("listo")
