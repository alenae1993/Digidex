"""Campaña 1 · La rebelión de Lucemon: cartas de Cambio de Destino y de Santuario en español.

Toma las hojas originales del mod y cambia solo lo que es de Sinnoh:
  assets/cards/change_of_fate/card_fronts.png  (2x2) Dialga/Palkia/Giratina/Arceus -> Seraphimon/Ophanimon/Cherubimon/Yggdrasil
  assets/cards/shrine/card_fronts_0.png        (4x2) eventos legendarios -> Goddramon, Holydramon, Megidramon, Omegamon,
                                                Duftmon, Craniummon, Huanglongmon y la Fractura Celestial de los Arcángeles
  assets/cards/shrine/card_fronts_1.png        (4x2) Bendiciones del Santuario (textos y alimentos en vez de bonguris)
Los reversos no tienen texto y se dejan igual. Las reglas de cada carta no cambian.

Uso: python cartas_destino_santuario_c1.py <carpeta del mod> <carpeta de salida>
Necesita cartas_acto_c1.py y arte_campana1.py en la misma carpeta, y los íconos de alimentos (assets/tokens/item_icons/apricorn_*.png)
ya convertidos por arte_campana1.py.
"""
import os
import sys

import numpy as np
from PIL import Image, ImageDraw, ImageFilter
from scipy import ndimage

import cartas_acto_c1 as T       # textos: barlow, oriental, draw_para, para_height, spaced
import arte_campana1 as A        # imágenes: quitar_fondo, fit, twemoji, outline

MOD = sys.argv[1] if len(sys.argv) > 1 else "."
OUT = sys.argv[2] if len(sys.argv) > 2 else "cartas_digimon"
CARDS = os.path.join(MOD, "assets/cards")
DIMG, BINGO, DREPO = A.DIMG, A.BINGO, "/tmp/claude-0/dimgrepo"
W, H = 2080, 3640
WHITE, DARK = (250, 250, 252), (37, 37, 50)


# --------------------------------------------------------------------------------------------------------------
# utilidades
# --------------------------------------------------------------------------------------------------------------
def row_fill(img, x0, x1, y0, y1, xl=None, xr=None):
    """Borra un rectángulo interpolando, fila por fila, entre el color del borde izquierdo y el derecho."""
    a = np.asarray(img).astype(np.float32).copy()
    xl = x0 - 6 if xl is None else xl
    xr = x1 + 6 if xr is None else xr
    t = np.linspace(0, 1, x1 - x0)[None, :, None]
    left = a[y0:y1, xl:xl + 1, :]
    right = a[y0:y1, xr:xr + 1, :]
    a[y0:y1, x0:x1, :] = left * (1 - t) + right * t
    return Image.fromarray(a.clip(0, 255).astype(np.uint8), img.mode)


def inpaint_box(img, x0, x1, y0, y1, thr=16, keep=None):
    """Borra lo que sobresale del fondo (texto, siluetas) dentro de un rectángulo y lo rellena con cv2.inpaint."""
    import cv2
    est = np.asarray(row_fill(img, x0, x1, y0, y1)).astype(np.int16)
    a = np.asarray(img).copy()
    diff = np.abs(a[..., :3].astype(np.int16) - est[..., :3]).max(axis=2)
    m = np.zeros(diff.shape, np.uint8)
    m[y0:y1, x0:x1] = (diff[y0:y1, x0:x1] > thr).astype(np.uint8) * 255
    m = cv2.dilate(m, np.ones((15, 15), np.uint8))
    if keep is not None:
        m[keep] = 0
    rgb = cv2.inpaint(np.ascontiguousarray(a[..., :3]), m, 12, cv2.INPAINT_TELEA)
    a[..., :3] = rgb
    return Image.fromarray(a, img.mode)


def silueta(path_or_img, w, h, col, glow=True):
    """Silueta oscura con borde brillante, como las de Cambio de Destino."""
    art = path_or_img if isinstance(path_or_img, Image.Image) else A.quitar_fondo(path_or_img)
    art = A.fit(art, w, h)
    m = np.asarray(art.split()[3]) > 60
    m = ndimage.binary_closing(m, iterations=3)
    m = ndimage.binary_fill_holes(m)
    m = ndimage.gaussian_filter(m.astype(np.float32), 7) > 0.5  # borde suave (las imágenes vienen de 320 px)
    pad = 60
    M = np.zeros((h + 2 * pad, w + 2 * pad), bool)
    M[pad:pad + h, pad:pad + w] = m
    out = Image.new("RGBA", M.shape[::-1], (0, 0, 0, 0))
    if glow:
        g = Image.fromarray((ndimage.binary_dilation(M, iterations=14) * 200).astype(np.uint8)).filter(ImageFilter.GaussianBlur(18))
        out.paste(Image.new("RGBA", out.size, col + (255,)), mask=g)
    dark = tuple(int(c * 0.38) for c in col)
    out.paste(Image.new("RGBA", out.size, dark + (255,)), mask=Image.fromarray((M * 235).astype(np.uint8)))
    edge = ndimage.binary_dilation(M, iterations=7) & ~ndimage.binary_erosion(M, iterations=2)
    light = tuple(min(255, int(c * 1.0 + 40)) for c in col)
    out.paste(Image.new("RGBA", out.size, light + (255,)), mask=Image.fromarray((edge * 255).astype(np.uint8)))
    return out


def con_halo(path, w, h, col):
    """Ilustración a todo color con un halo del color de la carta (eventos legendarios)."""
    art = A.fit(A.quitar_fondo(path), w, h)
    pad = 70
    canvas = Image.new("RGBA", (w + 2 * pad, h + 2 * pad), (0, 0, 0, 0))
    canvas.alpha_composite(art, (pad, pad))
    m = np.asarray(canvas.split()[3]) > 40
    g = Image.fromarray((ndimage.binary_dilation(m, iterations=18) * 220).astype(np.uint8)).filter(ImageFilter.GaussianBlur(16))
    out = Image.new("RGBA", canvas.size, (0, 0, 0, 0))
    out.paste(Image.new("RGBA", canvas.size, col + (255,)), mask=g)
    out.alpha_composite(canvas)
    return out


def estrella7(size):
    """Estrella de 7 puntas (el símbolo de la campaña), para la carta de Yggdrasil."""
    import math
    im = Image.new("RGBA", (size, size), (0, 0, 0, 0))
    d = ImageDraw.Draw(im)
    c, R, r = size / 2, size * 0.48, size * 0.22
    pts = [(c + (R if k % 2 == 0 else r) * math.cos(-math.pi / 2 + k * math.pi / 7),
            c + (R if k % 2 == 0 else r) * math.sin(-math.pi / 2 + k * math.pi / 7)) for k in range(14)]
    d.polygon(pts, fill=(255, 255, 255, 255))
    return im


def paste_center(img, im, cx, cy):
    img.alpha_composite(im, (int(cx - im.width / 2), int(cy - im.height / 2)))


def para_center(d, text, cx, top, bottom, size, width, color, min_size=70):
    while size > min_size and T.para_height(d, text, size, width, lh=1.2) > bottom - top:
        size -= 4
    h = T.para_height(d, text, size, width, lh=1.2)
    T.draw_para(d, text, cx, top + (bottom - top - h) / 2, size, width, color, lh=1.2, color=color)


# --------------------------------------------------------------------------------------------------------------
# 1. Cambio de Destino (2x2, 4163x7281)
# --------------------------------------------------------------------------------------------------------------
FATE = [  # subtítulo, imagen (o emoji), color, poder, poder "Juega 3"
    ("SERAPHIMON", f"{DIMG}/seraphimon.jpg", (50, 150, 250), "Relanzar 1", "Relanzar todos"),
    ("OPHANIMON", f"{DIMG}/ofanimon.jpg", (240, 60, 200), "Teletransporte 3", "Teletransporte libre"),
    ("CHERUBIMON", f"{DIMG}/cherubimon.jpg", (240, 60, 90), "Sacrificio 2", "Sacrificio total"),
    ("YGGDRASIL", "star", (250, 200, 80), "Comodín", "Bendición de Yggdrasil"),
]


def fate():
    sheet = Image.open(os.path.join(CARDS, "change_of_fate/card_fronts.png")).convert("RGBA")
    cw = sheet.width / 2
    for i, (name, src, col, p1, p3) in enumerate(FATE):
        x, y = round((i % 2) * cw), (i // 2) * H
        cell = sheet.crop((x, y, x + W, y + H))
        icon = cell.crop((1255, 3015, 1475, 3235))   # ícono del poder, junto a "PLAY 3" (recortado en círculo)
        cm = Image.new("L", icon.size, 0)
        ImageDraw.Draw(cm).ellipse((6, 6, icon.width - 6, icon.height - 6), fill=255)
        icon.putalpha(cm)
        yy, xx = np.mgrid[0:H, 0:W]
        circle = (np.hypot(xx - W / 2, yy - 2202) < 206) | (np.abs(yy - 2202) < 14)
        cell = inpaint_box(cell, 230, 1850, 150, 500)                 # título
        cell = inpaint_box(cell, 70, 2010, 450, 2060, keep=circle)    # silueta
        cell = row_fill(cell, 790, 1290, 1900, 1990)                  # justo sobre el círculo (sin arrastrar su color)
        est = np.asarray(row_fill(cell, 790, 1290, 1990, 2015))
        arr = np.asarray(cell).copy()
        fuera = (np.hypot(xx - W / 2, yy - 2202) > 203) & (yy >= 1990) & (yy < 2015) & (xx >= 790) & (xx < 1290)
        arr[fuera] = est[fuera]
        cell = Image.fromarray(arr, cell.mode)
        cell = inpaint_box(cell, 150, 1930, 2470, 2750)               # poder
        cell = inpaint_box(cell, 150, 1930, 2990, 3470)               # "PLAY 3" y poder fuerte
        d = ImageDraw.Draw(cell)
        d.text((W / 2, 240), "Cambio de Destino", font=T.barlow(165), fill=WHITE, anchor="mm")
        T.spaced(d, name, W / 2, 395, T.barlow(70), WHITE, 30)
        art = estrella7(900) if src == "star" else src
        paste_center(cell, silueta(art, 1500, 1360, col), W / 2, 1270)
        d = ImageDraw.Draw(cell)
        d.text((W / 2, 2610), p1, font=T.barlow(190), fill=WHITE, anchor="mm")
        f = T.oriental(150)
        tw = d.textlength("JUEGA 3", font=f)
        x0 = W / 2 - (tw + 40 + icon.width) / 2
        d.text((x0, 3125), "JUEGA 3", font=f, fill=col, anchor="lm")
        cell.alpha_composite(icon, (int(x0 + tw + 40), 3125 - icon.height // 2))
        s = 190
        while d.textlength(p3, font=T.barlow(s)) > 1700:
            s -= 6
        d.text((W / 2, 3335), p3, font=T.barlow(s), fill=WHITE, anchor="mm")
        sheet.paste(cell, (x, y))
    save(sheet, "change_of_fate/card_fronts.png")


# --------------------------------------------------------------------------------------------------------------
# 2. Eventos legendarios (santuarios, hoja 0)
# --------------------------------------------------------------------------------------------------------------
EVENTOS = [  # título, subtítulo, imagen, color del halo, santuario, texto
    ("El Trueno Divino", "GODDRAMON", f"{BINGO}/Goddramon.png", (120, 235, 240), "Santuario Canto Helado",
     "Todos los domadores obtienen 3 Pescados Frescos. Pon la ficha de Goddramon en el Santuario Canto Helado."),
    ("El Aliento Divino", "HOLYDRAMON", f"{BINGO}/Holydramon.png", (250, 235, 120), "Santuario Canto Trueno",
     "Todos los domadores obtienen 3 Bananas. Pon la ficha de Holydramon en el Santuario Canto Trueno."),
    ("El Fuego Divino", "MEGIDRAMON", f"{BINGO}/Megidramon.png", (250, 130, 120), "Santuario Canto Fuego",
     "Todos los domadores obtienen 3 Carnes. Pon la ficha de Megidramon en el Santuario Canto Fuego."),
    ("Un Caballero Eterno", "OMEGAMON", f"{BINGO}/Omegamon.png", (150, 240, 190), "Santuario Atemporal",
     "Todos los domadores obtienen 2 Piñas. Pon la ficha de Omegamon en el Santuario Atemporal."),
    ("Una Sombra Emerge", "DUFTMON", f"{BINGO}/Duftmon.png", (200, 200, 235), "Santuario Claro Lunar",
     "Todos los domadores obtienen 1 DigiProteína. Pon la ficha de Duftmon en el Santuario Claro Lunar (reemplaza la ficha de Craniummon)."),
    ("Un Faro de Luz", "CRANIUMMON", f"{BINGO}/Craniummon.png", (250, 190, 235), "Santuario Claro Lunar",
     "Todos los domadores obtienen 2 Manzanas. Pon la ficha de Craniummon en el Santuario Claro Lunar (reemplaza la ficha de Duftmon)."),
    ("Un Gigante Despierta", "HUANGLONGMON", f"{DREPO}/huanglongmon.jpg", (250, 240, 210), "Santuario del Coloso",
     "Todos los domadores obtienen 2 Zanahorias. Pon la ficha de Huanglongmon en el Santuario del Coloso."),
    ("Fractura Celestial", "LOS TRES ARCÁNGELES", None, None, "Altar de Yggdrasil",
     "Todos los domadores roban 1 carta de Cambio de Destino y pueden cambiar en secreto su ficha de Seguidor. "
     "Al revelarlas, pon en el Altar de Yggdrasil la ficha del Arcángel con más Seguidores (si hay empate, eliges tú)."),
]
PANEL = (36, 36, 2044, 2178)


def paisaje(cell):
    """Fondo del evento sin el Pokémon: bandas de color tomadas de los bordes de la carta y una montaña al centro."""
    a = np.asarray(cell).astype(np.float32)
    x0, y0, x1, y1 = PANEL
    edge = np.median(np.concatenate([a[y0:y1, 40:140, :], a[y0:y1, 1940:2040, :]], axis=1), axis=1)[:, None, :]
    edge = ndimage.gaussian_filter1d(edge, 10, axis=0)
    bg = np.repeat(edge, x1 - x0, axis=1)
    img = Image.fromarray(bg.clip(0, 255).astype(np.uint8), "RGBA")
    d = ImageDraw.Draw(img)
    mcol = tuple(int(v) for v in a[1000, 50, :3])
    pts = [(0, 880), (450, 690), (780, 590), (1004, 520), (1300, 620), (1650, 740), (x1 - x0, 820), (x1 - x0, 1400), (0, 1400)]
    d.polygon([(px, py - y0) for px, py in pts], fill=mcol + (255,))
    # vuelve a poner encima las bandas de árboles y suelo (de los bordes)
    low = Image.fromarray(bg.clip(0, 255).astype(np.uint8), "RGBA").crop((0, 1360 - y0, x1 - x0, y1 - y0))
    img.paste(low, (0, 1360 - y0))
    mask = Image.new("L", (W, H), 0)
    ImageDraw.Draw(mask).rounded_rectangle((x0, y0, x1, y1 + 200), 70, fill=255)
    cell.paste(img, (x0, y0), mask.crop((x0, y0, x1, y1)))


def fractura(cell):
    x0, y0, x1, y1 = PANEL
    img = Image.new("RGBA", (x1 - x0, y1 - y0), (60, 40, 80, 255))
    d = ImageDraw.Draw(img)
    for k in range(40):  # degradado radial
        r = 1500 - k * 35
        c = (60 + k * 2, 40 + k, 80 + k * 2, 255)
        d.ellipse((1004 - r, 1000 - r, 1004 + r, 1000 + r), fill=c)
    C = (1004, 1250 - y0)
    shards = {"top": ([(160, 470), (1850, 470), (1650, 1080), C, (380, 1080)], (200, 40, 70)),
              "left": ([(380, 1080), C, (1004, 2080), (120, 1900), (60, 1350)], (40, 90, 200)),
              "right": ([(1650, 1080), C, (1004, 2080), (1880, 1900), (1950, 1350)], (210, 40, 160))}
    for pts, col in shards.values():
        d.polygon(pts, fill=col + (255,), outline=(250, 235, 250, 255), width=10)
    img = img.filter(ImageFilter.GaussianBlur(1))
    for (key, (pts, col)), (src, w, h, cx, cy) in zip(shards.items(), [
            (f"{DIMG}/cherubimon.jpg", 660, 560, 1004, 800),
            (f"{DIMG}/seraphimon.jpg", 560, 560, 560, 1500),
            (f"{DIMG}/ofanimon.jpg", 560, 560, 1450, 1500)]):
        paste_center(img, silueta(src, w, h, tuple(min(255, c + 60) for c in col)), cx, cy)
    mask = Image.new("L", (W, H), 0)
    ImageDraw.Draw(mask).rounded_rectangle((x0, y0, x1, y1 + 200), 70, fill=255)
    cell.paste(img, (x0, y0), mask.crop((x0, y0, x1, y1)))


def eventos():
    sheet = Image.open(os.path.join(CARDS, "shrine/card_fronts_0.png")).convert("RGBA")
    for i, (title, sub, src, col, shrine, text) in enumerate(EVENTOS):
        x, y = (i % 4) * W, (i // 4) * H
        cell = sheet.crop((x, y, x + W, y + H))
        if src:
            paisaje(cell)
            paste_center(cell, con_halo(src, 1450, 1500, col), W / 2, 1290)
        else:
            fractura(cell)
        d = ImageDraw.Draw(cell)
        s = 170
        while d.textlength(title, font=T.barlow(s)) > 1880:
            s -= 6
        d.text((W / 2, 235), title, font=T.barlow(s), fill=WHITE, anchor="mm", stroke_width=3, stroke_fill=(90, 80, 110))
        T.spaced(d, sub, W / 2, 375, T.barlow(66), WHITE, 30)
        d.rectangle((280, 2200, 1760, 2480), fill=(63, 63, 75))
        d.text((300, 2345), shrine, font=T.barlow(112), fill=WHITE, anchor="lm")
        d.rounded_rectangle((140, 2620, 1940, 3500), 40, fill=(63, 63, 75))
        d.text((W / 2, 2742), "Evento Legendario", font=T.barlow(138), fill=WHITE, anchor="mm")
        para_center(d, text, W / 2, 2850, 3480, 108, 1720, WHITE)
        sheet.paste(cell, (x, y))
    save(sheet, "shrine/card_fronts_0.png")


# --------------------------------------------------------------------------------------------------------------
# 3. Bendiciones del Santuario (hoja 1)
# --------------------------------------------------------------------------------------------------------------
BENDICIONES = [
    ("Encuentro del Destino", "Roba 1/2/3 cartas de Cambio de Destino."),
    ("Regalo Inesperado", "Obtén 1/2/3 alimentos cualesquiera."),
    ("Intercambio Equivalente", "Puedes reemplazar un Digimon Débil/Moderado/Fuerte de tu equipo por cualquier Digimon "
                                "salvaje del mismo nivel, conservando todo lo demás que tenga asignado."),
    ("Sabiduría Ancestral", "Puedes aprender un ataque de un Digimon descartado de nivel Moderado/Fuerte/Legendario o menor."),
    ("Gran Banquete", "Usa gratis este turno los efectos de 1/2/3 comidas. No puedes elegir el mismo efecto de comida más de una vez."),
    ("Tesoro Escondido", "Obtén una Captura Mejorada/Avanzada/Ancestral."),
    ("Momento de Calma", "Obtén 2/4/6 Puntos de Viaje."),
]
CREAM = (250, 245, 240)


def estrella(d, cx, cy, r, fill=(255, 255, 255), edge=(60, 60, 70)):
    import math
    pts = [(cx + (r if k % 2 == 0 else r * 0.45) * math.cos(-math.pi / 2 + k * math.pi / 5),
            cy + (r if k % 2 == 0 else r * 0.45) * math.sin(-math.pi / 2 + k * math.pi / 5)) for k in range(10)]
    d.polygon(pts, fill=fill, outline=edge, width=6)


def fila_alimentos(cell):
    icons = os.path.join(MOD, "assets/tokens/item_icons")
    ico = {c: A.fit(Image.open(f"{icons}/apricorn_{c}.png").convert("RGBA"), 190, 190)
           for c in ("red", "yellow", "blue", "pink", "green", "white", "black")}
    d = ImageDraw.Draw(cell)
    d.rectangle((36, 2182, 2044, 2506), fill=CREAM)
    d.rectangle((36, 2506, 2044, 2570), fill=cell.getpixel((60, 2540)))
    groups = [(["red", "yellow", "blue"], 1), (["pink", "green", "white"], 2), (["black"], 3)]
    x, cy = 250, 2320
    for gi, (cols, stars) in enumerate(groups):
        gx0 = x
        for c in cols:
            cell.alpha_composite(ico[c], (int(x), cy - 95))
            x += 145
        gx1 = x + 45
        for s in range(stars):
            estrella(d, (gx0 + gx1) / 2 + (s - (stars - 1) / 2) * 85, cy + 120, 38)
        if gi < 2:
            d.text((x + 75, cy), "/", font=T.barlow(150), fill=(60, 60, 70), anchor="mm")
            x += 160


def bendiciones():
    sheet = Image.open(os.path.join(CARDS, "shrine/card_fronts_1.png")).convert("RGBA")
    for i, (title, text) in enumerate(BENDICIONES):
        x, y = (i % 4) * W, (i // 4) * H
        cell = sheet.crop((x, y, x + W, y + H))
        cell = inpaint_box(cell, 150, 1930, 140, 490)  # título sobre el cielo
        d = ImageDraw.Draw(cell)
        d.text((W / 2, 235), "Bendición del Santuario", font=T.barlow(160), fill=WHITE, anchor="mm",
               stroke_width=3, stroke_fill=(110, 150, 200))
        T.spaced(d, "MUNDO DIGITAL", W / 2, 375, T.barlow(66), WHITE, 30)
        d.rectangle((170, 1830, 1910, 2108), fill=CREAM)
        para_center(d, "4+ domadores: elige a otro domador para que también reciba este efecto", W / 2, 1835, 2095,
                    104, 1700, (55, 55, 65))
        fila_alimentos(cell)
        d = ImageDraw.Draw(cell)
        d.rectangle((160, 2600, 1920, 3536), fill=CREAM)
        s = 140
        while d.textlength(title, font=T.barlow(s)) > 1700:
            s -= 4
        d.text((W / 2, 2742), title, font=T.barlow(s), fill=(45, 45, 55), anchor="mm")
        para_center(d, text, W / 2, 2860, 3490, 110, 1700, (55, 55, 65))
        sheet.paste(cell, (x, y))
    save(sheet, "shrine/card_fronts_1.png")


def save(img, rel):
    p = os.path.join(OUT, rel)
    os.makedirs(os.path.dirname(p), exist_ok=True)
    img.save(p, optimize=True)


if __name__ == "__main__":
    fate()
    eventos()
    bendiciones()
    print("Listo:", OUT)
