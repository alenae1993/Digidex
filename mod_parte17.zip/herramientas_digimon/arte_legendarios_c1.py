"""Arte de los legendarios de la campaña 1 (La rebelión de Lucemon). Va junto con legendarios_c1.py.

Genera, con los nombres de archivo del mod:
  assets/card_generator/pokemon/1316..1337.png          ilustraciones de las cartas legendarias nuevas
  assets/card_generator/held_item_bases/*.png           objeto que exige la forma especial (plumas, Digimental, rosa)
  assets/tokens/legendary_tokens/*.png                  fichas de mapa (dialga = Seraphimon, articuno = Goddramon, etc.)
  assets/tokens/item_tokens/*.png, item_icons/*.png     artefactos de los santuarios

Uso: python arte_legendarios_c1.py carpeta_de_salida
Necesita arte_campana1.py en la misma carpeta (usa sus funciones) y las imágenes descargadas de los repos públicos.
"""
import os
import sys

import numpy as np
from PIL import Image, ImageFilter
from scipy import ndimage

import arte_campana1 as A

OUT = A.OUT
DIMG, BINGO = A.DIMG, A.BINGO
DREPO = "/tmp/claude-0/dimgrepo"
TY = "/tmp/r_tyreest19_PokemonVsDigimon/data/PokemonDigimon"

CARTAS = {
    1316: f"{DREPO}/Ophanimon_Falldown_Mode.jpg", 1317: f"{BINGO}/Cherubimon_Vice.png",
    1318: f"{BINGO}/ImperialdramonDragon_Mode.png", 1319: f"{BINGO}/ImperialdramonPaladin_Mode.png",
    1320: f"{BINGO}/Omegamon.png", 1321: f"{BINGO}/Examon.png", 1322: f"{DREPO}/huanglongmon.jpg",
    1323: f"{BINGO}/Craniummon.png", 1324: f"{BINGO}/Magnamon.png", 1325: f"{BINGO}/Duftmon.png",
    1326: f"{BINGO}/Dukemon.png", 1327: f"{BINGO}/DukemonCrimson_Mode.png", 1328: f"{DREPO}/baihumon.jpg",
    1329: f"{TY}/test/Digimon/120px-Xuanwumon.jpg", 1330: f"{TY}/train/Digimon/120px-Zhuqiaomon2.jpg",
    1331: f"{BINGO}/Goddramon.png", 1332: f"{BINGO}/Holydramon.png", 1333: f"{BINGO}/Megidramon.png",
    1334: f"{TY}/train/Digimon/120px-Ancientgarurumon.jpg", 1335: f"{TY}/train/Digimon/120px-Ancientwisemon.jpg",
    1336: f"{TY}/train/Digimon/120px-Ancientgreymon.jpg", 1337: f"{BINGO}/Susanoomon.png",
}
# fichas de mapa: nombre del mod -> imagen
FICHAS = {"dialga": f"{DIMG}/seraphimon.jpg", "palkia": f"{DIMG}/ofanimon.jpg", "giratina": f"{DIMG}/cherubimon.jpg",
          "articuno": f"{BINGO}/Goddramon.png", "zapdos": f"{BINGO}/Holydramon.png", "moltres": f"{BINGO}/Megidramon.png",
          "celebi": f"{BINGO}/Omegamon.png", "cresselia": f"{BINGO}/Craniummon.png", "darkrai": f"{BINGO}/Duftmon.png",
          "regigigas": f"{DREPO}/huanglongmon.jpg"}


def arte(path):
    im = A.quitar_fondo(path)
    if im.width < 200:  # las de 120 px: se agrandan y se les da un poco de nitidez
        k = 320 / im.width
        im = im.resize((round(im.width * k), round(im.height * k)), Image.LANCZOS)
        rgb = im.convert("RGB").filter(ImageFilter.UnsharpMask(radius=2, percent=80, threshold=2))
        rgb.putalpha(im.split()[3])
        im = rgb
    return im


def cartas():
    for num, path in CARTAS.items():
        A.save(A.fit(arte(path), 320, 320), f"card_generator/pokemon/{num}.png")


def ficha_legendaria(path, size=1819):
    """Como las del mod: la ilustración recortada con un halo blanco suave."""
    art = A.fit(arte(path), size - 160, size - 160)
    canvas = Image.new("RGBA", (size, size), (0, 0, 0, 0))
    canvas.alpha_composite(art, (80, 80))
    a = np.asarray(canvas.split()[3]) > 40
    grown = ndimage.binary_dilation(a, iterations=22)
    halo = Image.fromarray((grown * 255).astype(np.uint8)).filter(ImageFilter.GaussianBlur(10))
    out = Image.new("RGBA", (size, size), (255, 255, 255, 0))
    out.putalpha(halo)
    out.alpha_composite(canvas)
    return out


def fichas():
    for name, path in FICHAS.items():
        A.save(ficha_legendaria(path), f"tokens/legendary_tokens/{name}.png")


GOLD = dict(fill=(251, 224, 150), ring=(242, 192, 92))
CREAM = (248, 244, 239)
FEATHER = {"adamant": (245, 205, 90), "lustrous": (130, 200, 240), "griseous": (190, 120, 220)}


def objeto(code, col=None):
    im = A.twemoji(code, 560)
    if col:
        im = A.tint(im, col)
    return A.outline(im, 9)


def base_objeto(content, size=455):
    """Base del objeto que se dibuja en la carta (círculo crema, como en el mod)."""
    s = size * 4
    from PIL import ImageDraw
    im = Image.new("RGBA", (s, s), (0, 0, 0, 0))
    ImageDraw.Draw(im).ellipse((0, 0, s - 1, s - 1), fill=CREAM)
    im = im.resize((size, size), Image.LANCZOS)
    c = A.fit(content, round(size * 0.6), round(size * 0.6))
    im.alpha_composite(c, ((size - c.width) // 2, (size - c.height) // 2))
    return im


def artefactos():
    # (archivo del mod, emoji, color o None, ¿tiene ficha en item_tokens?, ícono en item_icons)
    items = [
        ("seafarer_egg", "1f95a", (245, 200, 80), True, "artifact_seafarer_egg"),     # Digihuevo de los Milagros (Magnamon)
        ("magma_stone", "1f409", (225, 80, 60), True, "artifact_magma_stone"),        # Escama de Examon
        ("odd_keystone", "1f6e1", None, True, "artifact_odd_keystone"),               # Escudo de Alphamon
        ("secret_key", "1f5dd", None, True, "secret_key"),                            # Llave del Digimental (Imperialdramon)
        ("gracidea_flower", "1f339", None, True, "artifact_gracidea_flower"),         # Rosa Carmesí (Dukemon)
        ("icesteel_core", "1f4a0", (90, 200, 230), True, "artifact_icesteel_core"),   # Digicore de Xuanwumon
        ("rockice_core", "1f4a0", (150, 170, 120), True, "artifact_rockice_core"),    # Digicore de Baihumon
        ("steelrock_core", "1f4a0", (230, 110, 70), True, "artifact_steelrock_core"), # Digicore de Zhuqiaomon
        ("omni_core", "1f4a0", (245, 205, 90), False, "artifact_omni_core"),          # Digicore de Huanglongmon
    ]
    for key, code, col, token, icon_name in items:
        o = objeto(code, col)
        A.save(A.fit(o, 780, 780), f"tokens/item_icons/{icon_name}.png")
        if token:
            A.save(A.on_disk(785, GOLD["fill"], o, ring=GOLD["ring"]), f"tokens/item_tokens/{key}.png")
    # bases de objeto de las cartas
    A.save(base_objeto(objeto("1f5dd")), "card_generator/held_item_bases/secret_key.png")
    A.save(base_objeto(objeto("1f339")), "card_generator/held_item_bases/gracidea_flower.png")
    for key, col in FEATHER.items():
        A.save(base_objeto(objeto("1fab6", col)), f"card_generator/held_item_bases/{key}_artifact.png")


if __name__ == "__main__":
    cartas()
    fichas()
    artefactos()
    print("archivos:", sum(len(f) for _, _, f in os.walk(OUT)))
