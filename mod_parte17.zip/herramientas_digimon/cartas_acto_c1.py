"""Campaña 1 · La rebelión de Lucemon: cartas de Acto (Prólogo, Actos I-III y Final) en español.

Toma las hojas originales del mod (assets/cards/act/card_fronts.png y backs.png, 4x2 cartas de 2080x3640),
borra los textos de Sinnoh y escribe los nuevos con las mismas fuentes, colores y diagramación.
El dorso conserva el marco y los números romanos; el símbolo de Arceus del Final se cambia por la estrella de 7 puntas.

Uso: python cartas_acto_c1.py <carpeta del mod> <carpeta de salida>
     (escribe <salida>/card_fronts.png y <salida>/backs.png con el mismo tamaño que los originales)
"""
import math
import os
import sys
from PIL import Image, ImageDraw, ImageFont

MOD = sys.argv[1] if len(sys.argv) > 1 else "."
OUT = sys.argv[2] if len(sys.argv) > 2 else "act_digimon"
FONTS = os.path.join(MOD, "assets/card_generator/fonts")
ACT = os.path.join(MOD, "assets/cards/act")
W, H = 2080, 3640
BG = (37, 37, 50, 255)
WHITE = (240, 240, 245)
DARK = (37, 37, 50)
COL = {"rosa": (247, 150, 247), "verde": (100, 200, 100), "azul": (100, 150, 250),
       "rojo": (245, 100, 100), "amarillo": (250, 200, 90)}


def barlow(s):
    return ImageFont.truetype(os.path.join(FONTS, "barlow.ttf"), s)


def oriental(s):
    return ImageFont.truetype(os.path.join(FONTS, "la_oriental.otf"), s)


# --- texto con resaltados: "[palabra]" va en color --------------------------------------------------------------
def tokens(text, accent):
    out, color, buf = [], WHITE, ""
    for ch in text:
        if ch in "[]":
            if buf:
                out.append((buf, color))
            buf, color = "", (accent if ch == "[" else WHITE)
        else:
            buf += ch
    if buf:
        out.append((buf, color))
    words, pending = [], False  # (palabra, color, espacio_antes)
    for seg, c in out:
        for i, part in enumerate(seg.split(" ")):
            if i > 0:
                pending = True
            if part:
                words.append([part, c, pending])
                pending = False
    if words:
        words[0][2] = False
    return words


def wrap(d, words, font, width):
    lines, cur = [], []
    sp = d.textlength(" ", font=font)
    for w in words:
        trial = cur + [w]
        lw = sum(d.textlength(x[0], font=font) for x in trial) + sp * sum(1 for x in trial[1:] if x[2])
        if cur and lw > width:
            lines.append(cur)
            cur = [[w[0], w[1], False]]
        else:
            cur = trial
    if cur:
        lines.append(cur)
    return lines


def para_height(d, text, size, width, lh=1.26):
    font = barlow(size)
    n = sum(len(wrap(d, tokens(p, WHITE), font, width)) or 0.5 for p in text.split("\n"))
    return n * size * lh


def draw_para(d, text, cx, y, size, width, accent, lh=1.26, color=None):
    font = barlow(size)
    sp = d.textlength(" ", font=font)
    for p in text.split("\n"):
        if not p.strip():
            y += size * lh * 0.5
            continue
        for line in wrap(d, tokens(p, accent), font, width):
            lw = sum(d.textlength(x[0], font=font) for x in line) + sp * sum(1 for x in line if x[2])
            x = cx - lw / 2
            for word, c, space in line:
                if space:
                    x += sp
                d.text((x, y), word, font=font, fill=color or c)
                x += d.textlength(word, font=font)
            y += size * lh
    return y


def spaced(d, text, cx, y, font, fill, track):
    lw = sum(d.textlength(c, font=font) for c in text) + track * (len(text) - 1)
    x = cx - lw / 2
    for c in text:
        d.text((x, y), c, font=font, fill=fill)
        x += d.textlength(c, font=font) + track


# --- frente -------------------------------------------------------------------------------------------------------
BOX_X0, BOX_X1, R = 95, W - 95, 150


def front(cell, card):
    img = cell.copy()
    d = ImageDraw.Draw(img)
    d.rectangle((70, 70, W - 70, H - 70), fill=BG)
    acc = COL[card["color"]]
    cx = W // 2
    d.text((cx, 245), card["titulo"], font=barlow(190), fill=acc, anchor="mm")
    spaced(d, card["sub"].upper(), cx, 385, barlow(78), WHITE, 34)
    y = draw_para(d, card["cuerpo"], cx, 590, 104, 1720, acc, lh=1.24)

    if "objetivo" in card:
        y += 120
        th = para_height(d, card["objetivo"], 100, 1640)
        top, head_h, rew_h = y, 290, 250
        bottom = top + head_h + th + 110 + rew_h
        d.rounded_rectangle((BOX_X0, top, BOX_X1, bottom), R, fill=BG, outline=acc, width=14)
        d.rounded_rectangle((BOX_X0, bottom - rew_h, BOX_X1, bottom), R, fill=acc, corners=(False, False, True, True))
        d.text((cx, top + 150), "Objetivo", font=barlow(150), fill=acc, anchor="mm")
        draw_para(d, card["objetivo"], cx, top + head_h, 100, 1640, acc)
        rs = 116
        while d.textlength(card["recompensa"], font=barlow(rs)) > 1780:
            rs -= 4
        d.text((cx, bottom - rew_h / 2 - 8), card["recompensa"], font=barlow(rs), fill=DARK, anchor="mm")
        fh = para_height(d, card["pie"], 124, 1760, lh=1.22)
        fy = max(bottom + 90, H - 150 - fh)
        draw_para(d, card["pie"], cx, fy, 124, 1760, acc, lh=1.22)
    elif "finales" not in card:  # Prólogo: solo el texto de abajo
        fh = para_height(d, card["pie"], 124, 1760, lh=1.22)
        draw_para(d, card["pie"], cx, max(y + 90, H - 150 - fh), 124, 1760, acc, lh=1.22)
    else:  # Final: dos recuadros
        y += 100
        boxes = card["finales"]
        for name, text, size in boxes:
            th = para_height(d, text, size, 1660, lh=1.22)
            top, bottom = y, y + 210 + th + 70
            d.rounded_rectangle((BOX_X0, top, BOX_X1, bottom), R, fill=BG, outline=acc if name.startswith("Hé") else COL["rojo"], width=14)
            hc = acc if name.startswith("Hé") else COL["rojo"]
            ns = 140
            while d.textlength(name, font=barlow(ns)) > 1700:
                ns -= 4
            d.text((cx, top + 125), name, font=barlow(ns), fill=hc, anchor="mm")
            draw_para(d, text, cx, top + 215, size, 1660, acc, lh=1.22)
            y = bottom + 60
    return img


# --- dorso ------------------------------------------------------------------------------------------------------
def star(d, cx, cy, r1, r2, n, fill):
    pts = []
    for i in range(2 * n):
        r = r1 if i % 2 == 0 else r2
        a = -math.pi / 2 + i * math.pi / n
        pts.append((cx + r * math.cos(a), cy + r * math.sin(a)))
    d.polygon(pts, fill=fill)


def back(cell, label, color, replace_symbol):
    img = cell.copy()
    d = ImageDraw.Draw(img)
    bg = (38, 38, 50, 255)
    d.rectangle((260, 470, W - 260, 820), fill=bg)
    d.rectangle((260, 2560, W - 260, 3330), fill=bg)
    cx = W // 2
    s = 190
    while d.textlength(label, font=oriental(s)) > 1450:
        s -= 6
    d.text((cx, 650), label, font=oriental(s), fill=(250, 246, 240), anchor="mm")
    if replace_symbol:
        d.rectangle((260, 900, W - 260, 2500), fill=bg)
        star(d, cx, 1720, 640, 270, 7, color)
        d.ellipse((cx - 150, 1720 - 150, cx + 150, 1720 + 150), fill=bg)
        star(d, cx, 1720, 120, 55, 7, color)
    spaced(d, "LA", cx, 2640, barlow(82), WHITE, 18)
    d.text((cx, 2880), "REBELIÓN DE", font=oriental(150), fill=(250, 246, 240), anchor="mm")
    d.text((cx, 3070), "LUCEMON", font=oriental(170), fill=(250, 246, 240), anchor="mm")
    spaced(d, "CAMPAÑA", cx, 3195, barlow(82), WHITE, 18)
    return img


CARDS = [
    dict(color="rosa", titulo="La Incursión", sub="Prólogo",
         cuerpo="Lucemon, el ángel caído de la Soberbia, se rebeló contra Yggdrasil y abrió las Puertas de los Señores Demonio.\n\n"
                "Sin fuerzas para detenerlo, los tres Arcángeles llamaron a domadores del mundo real y les entregaron su primer Digimon.\n\n"
                "Para que nadie se le oponga, los Soldados Pesadilla ya ocupan las aldeas de la región.",
         pie="Pon una ficha de «Soldados Pesadilla» boca arriba en la aldea natal de cada domador. No puedes volar hacia ni desde "
             "una aldea con esta ficha. Roba la carta del [Acto I]."),
    dict(color="verde", titulo="El Viaje", sub="Acto I",
         cuerpo="Los Digimon de tu aldea temen enfrentarse a los Soldados Pesadilla. Emprende un viaje para capturar y entrenar un "
                "pequeño equipo capaz de liberar tu hogar.\n\nAl partir, llevas [3 Carnes] para preparar tus primeras Capturas.",
         objetivo="Vence a los 2 Soldados Pesadilla de tu aldea natal.",
         recompensa="Recompensa: +2 de movimiento",
         pie="Cuando un domador cumpla este objetivo: roba la carta del [Acto II] y da vuelta las fichas de las seis Puertas."),
    dict(color="azul", titulo="Los Emblemas", sub="Acto II",
         cuerpo="Los seis Emblemas que encienden la Luz están sellados tras las Puertas de los Pecados.\n\n"
                "Cada Puerta la custodia un Señor Demonio: [Lilithmon], [Barbamon], [Daemon], [Leviamon], [Belphemon] y "
                "[Beelzemon]. Mientras más Emblemas tengas, más Digimon usarán contra ti.",
         objetivo="Vence a los 6 Señores Demonio en sus Puertas para reunir los seis Emblemas.",
         recompensa="Recompensa: +1 espacio cada 2 Emblemas",
         pie="Cuando un domador cumpla este objetivo: roba la carta del [Acto III] y da vuelta la ficha de la Puerta de Cocytus."),
    dict(color="rojo", titulo="La Luz", sub="Acto III",
         cuerpo="Sin la Luz, Yggdrasil cae bajo el control de Lucemon y el Mundo Digital empieza a reescribirse a su voluntad.\n\n"
                "Ofrece los seis Emblemas en el [Altar de Yggdrasil] para obtener el Emblema de la Luz y luego avanza a la "
                "[Puerta de Cocytus] para enfrentar a Lucemon.",
         objetivo="Vence a Lucemon en la Puerta de Cocytus.",
         recompensa="Recompensa: carta del Final",
         pie="Cuando un domador cumpla este objetivo: roba la carta del [Final]."),
    dict(color="amarillo", titulo="La Elección", sub="Final",
         cuerpo="¿Se acabó? Los Arcángeles, libres al fin, miran el Emblema de la Luz que sostienes en tus manos.\n\n"
                "Pero con este poder, el Mundo Digital podría cambiar... para bien. Alguien como Lucemon jamás volvería a "
                "levantarse... ¿verdad?",
         finales=[("Héroe del Mundo Digital", "Sella a Lucemon con el Emblema de la Luz y vuelve al mundo real.", 104),
                  ("Traidor del Mundo Digital", "Quédate con el Emblema de la Luz. Desafía y vence en combate a cada uno de los "
                                                "otros domadores para coronarte como el más fuerte.", 118)]),
]
LABELS = ["PRÓLOGO", "CARTA DE ACTO", "CARTA DE ACTO", "CARTA DE ACTO", "FINAL"]


def main():
    os.makedirs(OUT, exist_ok=True)
    fr = Image.open(os.path.join(ACT, "card_fronts.png")).convert("RGBA")
    bk = Image.open(os.path.join(ACT, "backs.png")).convert("RGBA")
    for i, card in enumerate(CARDS):
        x, y = (i % 4) * W, (i // 4) * H
        box = (x, y, x + W, y + H)
        fr.paste(front(fr.crop(box), card), (x, y))
        bk.paste(back(bk.crop(box), LABELS[i], COL[card["color"]], i == 4), (x, y))
    fr.save(os.path.join(OUT, "card_fronts.png"))
    bk.save(os.path.join(OUT, "backs.png"))
    print("Cartas de Acto listas en", OUT)


if __name__ == "__main__":
    main()
