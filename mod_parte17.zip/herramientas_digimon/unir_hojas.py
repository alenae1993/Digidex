"""Une las hojas que se subieron a GitHub partidas en dos (GitHub no acepta archivos tan grandes desde el navegador).
Uso: python unir_hojas.py <carpeta pokemon-legends-master>
"""
import os, sys
from PIL import Image
MOD = sys.argv[1] if len(sys.argv) > 1 else ".."
for rel in ["assets/cards/village/card_fronts.png", "assets/cards/shrine/card_fronts_0.png"]:
    p1 = os.path.join(MOD, rel[:-4] + ".parte1.png"); p2 = os.path.join(MOD, rel[:-4] + ".parte2.png")
    if os.path.exists(p1) and os.path.exists(p2):
        a, b = Image.open(p1), Image.open(p2)
        out = Image.new(a.mode, (a.width, a.height + b.height)); out.paste(a, (0, 0)); out.paste(b, (0, a.height))
        out.save(os.path.join(MOD, rel)); os.remove(p1); os.remove(p2); print("unida:", rel)
