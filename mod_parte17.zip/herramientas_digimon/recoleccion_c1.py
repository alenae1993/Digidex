"""Lugares de recolección: los bonguris dibujados en los árboles y arrecifes pasan a ser los alimentos Digimon.

En las fichas de árbol (<color>_<clima>.png, green.png, yellow.png) y de arrecife (reef_*.png) del mod los 3 bonguris
están siempre en el mismo lugar. Cada uno se borra (cv2.inpaint) y se reemplaza por el alimento de su color:
  rojo = Carne, amarillo = Banana, azul = Pescado Fresco, rosado = Manzana, verde = Piña, blanco = Zanahoria,
  negro = DigiProteína (los mismos de economia_alimentos.md). Íconos: Twemoji (CC-BY 4.0).
Uso: python recoleccion_c1.py <carpeta del mod> <salida>
"""
import os
import sys

import cv2
import numpy as np
from PIL import Image

MOD, OUT = sys.argv[1], sys.argv[2]
sys.argv = [sys.argv[0], OUT]
import arte_campana1 as A

WT = os.path.join(MOD, "assets/tokens/world_tokens")
POS = [(325, 194), (228, 357), (422, 357)]
PALETA = {"red": (225, 45, 45), "yellow": (245, 200, 40), "blue": (40, 90, 220), "pink": (240, 160, 200),
          "green": (60, 180, 80), "white": (225, 225, 240), "black": (60, 60, 80)}
COMIDA = {"red": "1f356", "yellow": "1f34c", "blue": "1f41f", "pink": "1f34e", "green": "1f34d", "white": "1f955",
          "black": "1f48a"}
ARCHIVOS = ["black_cold", "black_temperate", "black_warm", "blue_cold", "blue_temperate", "blue_warm", "pink_cold",
            "red_cold", "red_temperate", "red_warm", "white_warm", "yellow", "yellow_cold", "yellow_warm", "green",
            "reef_weak", "reef_moderate", "reef_strong"]


def color_de(a, x, y):
    c = a[y - 25:y + 25, x - 5:x + 35, :3].reshape(-1, 3).mean(axis=0)
    return min(PALETA, key=lambda k: sum((c[i] - PALETA[k][i]) ** 2 for i in range(3)))


def main():
    iconos = {k: A.outline(A.twemoji(v, 200), 6) for k, v in COMIDA.items()}
    for f in ARCHIVOS:
        src = os.path.join(WT, f + ".png")
        if not os.path.exists(src):
            print("falta", f)
            continue
        im = Image.open(src).convert("RGBA")
        a = np.asarray(im).copy()
        cols = [color_de(a, x, y) for x, y in POS]
        mask = np.zeros(a.shape[:2], np.uint8)
        for x, y in POS:
            cv2.circle(mask, (x, y), 84, 255, -1)
            cv2.circle(mask, (x - 30, y - 64), 52, 255, -1)  # la "tapa" del bonguri
        rgb = cv2.inpaint(np.ascontiguousarray(a[..., :3]), mask, 9, cv2.INPAINT_TELEA)
        a[..., :3] = rgb
        out = Image.fromarray(a, "RGBA")
        for (x, y), c in zip(POS, cols):
            ic = iconos[c]
            out.alpha_composite(ic, (x - ic.width // 2, y - ic.height // 2 - 10))
        # la máscara de legendario de abajo va encima, como en el original
        orig = np.asarray(im)
        eye = np.zeros(a.shape[:2], bool)
        eye[420:, 200:450] = True
        top = Image.fromarray(np.where(eye[..., None], orig, 0).astype(np.uint8), "RGBA")
        out.alpha_composite(top)
        A.save(out, f"tokens/world_tokens/{f}.png")
        print(f, cols)


if __name__ == "__main__":
    main()
