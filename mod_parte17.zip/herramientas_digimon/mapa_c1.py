"""Mapa del Mundo Digital para la campaña 1 (La rebelión de Lucemon).

El tablero de Tabletop Simulator se arma con hexágonos que el mod coloca en la partida guardada; esa disposición NO
cambia (de ella depende que existan las 12 combinaciones de bioma y clima de las cartas). Lo que cambia es la identidad:
cada zona del mapa recibe un nombre del Mundo Digital y se marcan las 6 Puertas de los Pecados y la Puerta de Cocytus.

Genera:
  assets/bases/pokedex/map_full.png   el mapa de referencia del mod, con los nombres y las puertas encima
  mapa_mundo_digital.png              un póster del mapa (fondo oscuro, título y leyenda) para ver o imprimir

Uso: python mapa_c1.py <carpeta del mod> <salida>
"""
import math
import os
import sys

from PIL import Image, ImageDraw, ImageFilter

MOD, OUT = sys.argv[1], sys.argv[2]
sys.argv = [sys.argv[0], MOD, OUT]
import cartas_acto_c1 as T

S = 8315 / 1600  # las coordenadas de abajo están en la vista de 1600 px

# nombre, (x, y) en la vista de 1600 px, tamaño relativo
ZONAS = [
    ("Freezeland", (777, 379), 1.0), ("Tundra Glaciar", (204, 856), 0.8),
    ("Cumbres de Freezeland", (835, 560), 0.6), ("Picos Helados", (491, 597), 0.6), ("Montes Escarcha", (293, 940), 0.7),
    ("Pantano Brumoso", (700, 470), 0.75), ("Bosque Nevado", (226, 1031), 0.8),
    ("Mar del Norte", (463, 520), 0.9),
    ("Llanura del Comienzo", (476, 948), 0.85), ("Pueblo Juguete", (1005, 789), 0.85),
    ("Monte Infinito", (770, 1020), 1.0), ("Montaña Basura", (830, 1165), 0.75),
    ("Arboleda Digital", (931, 706), 0.55), ("Bosque Nativo", (1256, 859), 0.8), ("Selva Esmeralda", (603, 1073), 0.75),
    ("Sabana del Engranaje", (1270, 610), 0.7), ("Llanos de Metal", (1447, 628), 0.6),
    ("Pradera Factorial", (1316, 1014), 0.7), ("Desierto de Datos", (794, 1300), 0.8),
    ("Jungla Escarabajo", (1039, 432), 0.6), ("Tierra de los Escarabajos", (1009, 1085), 0.8),
    ("Gran Cañón", (1150, 285), 0.75), ("Mesa Roja", (1381, 706), 0.6), ("Monte Volcánico", (1128, 929), 0.7),
    ("Canal del Server", (1187, 706), 0.55), ("Fosa Abisal", (330, 1205), 0.75),
    ("Mar Cálido del Server", (1440, 1080), 0.7),
]
# Puertas: (Señor Demonio, pecado, color, posición)
PUERTAS = [
    ("Lilithmon", "Lujuria", (200, 90, 170), (575, 690)),
    ("Barbamon", "Codicia", (220, 180, 60), (700, 1120)),
    ("Daemon", "Ira", (210, 70, 60), (1235, 410)),
    ("Leviamon", "Envidia", (60, 120, 200), (420, 1150)),
    ("Belphemon", "Pereza", (100, 150, 110), (715, 680)),
    ("Beelzemon", "Gula", (150, 70, 160), (1105, 600)),
]
COCYTUS = (779, 815)


def estrella(d, cx, cy, R, r, n, fill, outline=None, width=0):
    pts = [(cx + (R if k % 2 == 0 else r) * math.cos(-math.pi / 2 + k * math.pi / n),
            cy + (R if k % 2 == 0 else r) * math.sin(-math.pi / 2 + k * math.pi / n)) for k in range(2 * n)]
    d.polygon(pts, fill=fill, outline=outline, width=width)


def etiquetas(img, k=S):
    d = ImageDraw.Draw(img)
    for name, (x, y), sz in ZONAS:
        f = T.barlow(int(26 * sz * k))
        d.text((x * k, y * k), name, font=f, fill=(255, 255, 255), anchor="mm",
               stroke_width=max(2, int(4 * k)), stroke_fill=(37, 37, 50))
    for lord, sin, col, (x, y) in PUERTAS:
        cx, cy = x * k, y * k
        estrella(d, cx, cy, 30 * k, 13 * k, 7, col, outline=(37, 37, 50), width=max(2, int(3 * k)))
        d.text((cx, cy + 40 * k), sin, font=T.barlow(int(15 * k)), fill=(255, 245, 200), anchor="mm",
               stroke_width=max(2, int(3 * k)), stroke_fill=(37, 37, 50))
    cx, cy = COCYTUS[0] * k, COCYTUS[1] * k
    estrella(d, cx, cy, 40 * k, 17 * k, 7, (245, 245, 250), outline=(37, 37, 50), width=max(2, int(4 * k)))
    estrella(d, cx, cy, 14 * k, 6 * k, 7, (37, 37, 50))
    d.text((cx, cy - 56 * k), "Puerta de Cocytus", font=T.barlow(int(20 * k)), fill=(255, 245, 200), anchor="mm",
           stroke_width=max(2, int(3 * k)), stroke_fill=(37, 37, 50))


def poster(base):
    Wp, Hp = 3600, 4300
    bg = Image.new("RGBA", (Wp, Hp), (20, 22, 38, 255))
    d = ImageDraw.Draw(bg)
    for gx in range(0, Wp, 90):           # rejilla digital
        d.line((gx, 0, gx, Hp), fill=(30, 40, 66, 255), width=2)
    for gy in range(0, Hp, 90):
        d.line((0, gy, Wp, gy), fill=(30, 40, 66, 255), width=2)
    m = base.resize((3400, 3400), Image.LANCZOS)
    glow = m.split()[3].filter(ImageFilter.GaussianBlur(25))
    halo = Image.new("RGBA", m.size, (80, 170, 255, 255))
    halo.putalpha(glow.point(lambda v: v * 0.6))
    bg.alpha_composite(halo, (100, 380))
    bg.alpha_composite(m, (100, 380))
    d = ImageDraw.Draw(bg)
    d.text((Wp / 2, 130), "EL MUNDO DIGITAL", font=T.oriental(170), fill=(250, 246, 240), anchor="mm")
    T.spaced(d, "LA REBELIÓN DE LUCEMON  ·  ISLA FILE", Wp / 2, 250, T.barlow(64), (170, 200, 240), 14)
    y = 3800
    d.text((140, y), "Puertas de los Pecados (Acto II)", font=T.barlow(64), fill=(250, 246, 240), anchor="lm")
    for i, (lord, sin, col, _) in enumerate(PUERTAS):
        x = 140 + (i % 3) * 1150
        yy = y + 110 + (i // 3) * 110
        estrella(d, x + 30, yy, 34, 15, 7, col, outline=(250, 246, 240), width=3)
        d.text((x + 90, yy), f"{sin}: {lord}", font=T.barlow(58), fill=(220, 225, 240), anchor="lm")
    d.text((Wp - 140, y), "Puerta de Cocytus: Lucemon (Acto III)", font=T.barlow(52), fill=(255, 245, 200), anchor="rm")
    return bg


if __name__ == "__main__":
    base = Image.open(os.path.join(MOD, "assets/bases/pokedex/map_full.png")).convert("RGBA")
    etiquetas(base)
    p = os.path.join(OUT, "bases/pokedex/map_full.png")
    os.makedirs(os.path.dirname(p), exist_ok=True)
    base.save(p, optimize=True)
    poster(base).convert("RGB").save(os.path.join(OUT, "mapa_mundo_digital.png"), quality=92)
    print("listo")
