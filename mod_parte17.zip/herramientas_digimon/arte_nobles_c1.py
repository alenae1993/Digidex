"""Arte de las Formas Nobles Digimon (va con nobles_c1.py).

  assets/card_generator/pokemon/{num}-n.png      la ilustración de la carta base con aura dorada (como los Nobles del mod)
  assets/card_generator/held_item_bases/scroll_of_nobility.png, tokens/item_tokens|item_icons/scroll_of_nobility.png
                                                 el "Pergamino de Nobleza" pasa a ser un pergamino dorado (Twemoji 1f4dc)
Uso: python arte_nobles_c1.py <carpeta pokemon del mod> <carpeta de salida>
"""
import os
import sys

import numpy as np
from PIL import Image, ImageFilter
from scipy import ndimage

sys.argv = [sys.argv[0], sys.argv[2] if len(sys.argv) > 2 else "salida"] + sys.argv[1:]
import arte_campana1 as A
import arte_legendarios_c1 as L

SRC = sys.argv[2] if len(sys.argv) > 2 else "pokemon"
OUT = A.OUT
NUMS = [4, 8, 12, 18, 1011, 1023, 1026, 1041, 1043, 1049, 1059, 1062, 1067, 1081, 1104, 1111, 1169, 1175]
GOLD = (255, 205, 70)


def noble(im):
    s = im.size[0]
    art = A.fit(im, int(s * 0.86), int(s * 0.86))
    canvas = Image.new("RGBA", im.size, (0, 0, 0, 0))
    canvas.alpha_composite(art, ((s - art.width) // 2, (s - art.height) // 2))
    m = np.asarray(canvas.split()[3]) > 40
    glow = Image.fromarray((ndimage.binary_dilation(m, iterations=9) * 255).astype(np.uint8)).filter(ImageFilter.GaussianBlur(6))
    out = Image.new("RGBA", im.size, (0, 0, 0, 0))
    out.paste(Image.new("RGBA", im.size, GOLD + (255,)), mask=glow)
    out.alpha_composite(canvas)
    return out


if __name__ == "__main__":
    for n in NUMS:
        name = f"{n:03}"
        A.save(noble(Image.open(os.path.join(SRC, f"{name}.png")).convert("RGBA")), f"card_generator/pokemon/{name}-n.png")
    o = L.objeto("1f4dc", (245, 200, 90))
    A.save(L.base_objeto(o), "card_generator/held_item_bases/scroll_of_nobility.png")
    A.save(A.fit(o, 780, 780), "tokens/item_icons/scroll_of_nobility.png")
    A.save(A.on_disk(785, L.GOLD["fill"], o, ring=L.GOLD["ring"]), "tokens/item_tokens/scroll_of_nobility.png")
    print("listo")
