"""Arte de la campaña 1 (La rebelión de Lucemon) y fichas de objetos Digimon.

Genera, con los MISMOS nombres de archivo que usa el mod (así no hay que tocar el generador ni el TTS):
  assets/card_generator/pokemon/1306..1315.png        Digimon nuevos (villanos)
  assets/card_generator/trainers/*.png                 retratos de las cartas de villano
  assets/card_generator/encounter_icons/galactic.png   ícono de villano (estrella de los 7 pecados)
  assets/card_generator/card_backs/{grunt,commander,boss}.png
  assets/tokens/item_icons, item_tokens, poke_ball_tokens, heart_shards, celestial_icons, galactic_tokens

Uso: python arte_campana1.py carpeta_de_salida
Íconos de comida y objetos: Twemoji (CC-BY 4.0, https://github.com/jdecked/twemoji), con borde y fondo propios.
"""
import io, math, os, sys
import cairosvg
import numpy as np
from PIL import Image, ImageDraw, ImageFilter, ImageFont, ImageOps
from scipy import ndimage

OUT = sys.argv[1] if len(sys.argv) > 1 else "salida"
TW = "/tmp/claude-0/tw"
FONTS = "/mnt/user-data/uploads/pokemon-legends-master/assets/card_generator/fonts"
DIMG = "/tmp/dimg"
BINGO = "/tmp/r_TheWitchSaphire_digimon-bingo-images/digimon_images"
INK = (37, 37, 50)


def font(size, title=False):
    return ImageFont.truetype(f"{FONTS}/{'la_oriental.otf' if title else 'barlow.ttf'}", size)


def save(img, rel):
    p = os.path.join(OUT, rel)
    os.makedirs(os.path.dirname(p), exist_ok=True)
    img.save(p, optimize=True)


def quitar_fondo(path, umbral=28):
    im = Image.open(path).convert("RGB")
    a = np.asarray(im).astype(np.int16)
    white = (a >= 255 - umbral).all(axis=2)
    lab, _ = ndimage.label(white)
    border = set(np.unique(np.concatenate([lab[0], lab[-1], lab[:, 0], lab[:, -1]]))) - {0}
    bg = np.isin(lab, list(border))
    alpha = np.where(bg, 0, 255).astype(np.uint8)
    edge = ndimage.binary_dilation(bg) & ~bg
    soft = np.clip((255 - a.min(axis=2)) * 255 // (umbral * 3), 60, 255).astype(np.uint8)
    alpha[edge] = np.minimum(alpha[edge], soft[edge])
    return Image.fromarray(np.dstack([np.asarray(im), alpha]), "RGBA")


def crop_alpha(im, pad=4):
    bb = im.getbbox()
    if not bb:
        return im
    x0, y0, x1, y1 = bb
    return im.crop((max(0, x0 - pad), max(0, y0 - pad), min(im.width, x1 + pad), min(im.height, y1 + pad)))


def fit(im, w, h, anchor="center"):
    im = crop_alpha(im)
    k = min(w / im.width, h / im.height)
    im = im.resize((max(1, round(im.width * k)), max(1, round(im.height * k))), Image.LANCZOS)
    canvas = Image.new("RGBA", (w, h), (0, 0, 0, 0))
    x = (w - im.width) // 2
    y = h - im.height if anchor == "bottom" else (h - im.height) // 2
    canvas.alpha_composite(im, (x, y))
    return canvas


def outline(im, width, color=INK):
    """Borde oscuro alrededor de la silueta (como los íconos del mod)."""
    a = np.asarray(im.split()[3]) > 40
    grown = ndimage.binary_dilation(a, iterations=width)
    base = Image.new("RGBA", im.size, (0, 0, 0, 0))
    base.paste(Image.new("RGBA", im.size, color + (255,)), mask=Image.fromarray((grown * 255).astype(np.uint8)))
    base.alpha_composite(im)
    return base


def twemoji(code, size):
    png = cairosvg.svg2png(url=f"{TW}/{code}.svg", output_width=size, output_height=size)
    return Image.open(io.BytesIO(png)).convert("RGBA")


def icon(code, size, pad=0.12, border=None):
    inner = round(size * (1 - 2 * pad))
    im = twemoji(code, inner)
    canvas = Image.new("RGBA", (size, size), (0, 0, 0, 0))
    canvas.alpha_composite(im, ((size - inner) // 2, (size - inner) // 2))
    return outline(canvas, border or max(4, size // 55))


def disk(size, fill, ring=None, ring_w=0.07, edge=INK):
    """Ficha redonda: borde oscuro, anillo de color y fondo."""
    s = size * 4
    im = Image.new("RGBA", (s, s), (0, 0, 0, 0))
    d = ImageDraw.Draw(im)
    e = round(s * 0.025)
    d.ellipse((e, e, s - e, s - e), fill=edge)
    if ring:
        r = round(s * 0.045)
        d.ellipse((r, r, s - r, s - r), fill=ring)
        r2 = round(s * (0.045 + ring_w))
        d.ellipse((r2 - e, r2 - e, s - r2 + e, s - r2 + e), fill=edge)
        d.ellipse((r2, r2, s - r2, s - r2), fill=fill)
    else:
        r = round(s * 0.05)
        d.ellipse((r, r, s - r, s - r), fill=fill)
    return im.resize((size, size), Image.LANCZOS)


def on_disk(size, fill, content, ring=None, scale=0.62, dy=0.0):
    t = disk(size, fill, ring)
    c = fit(content, round(size * scale), round(size * scale))
    t.alpha_composite(c, ((size - c.width) // 2, round((size - c.height) / 2 + dy * size)))
    return t


def text_center(d, xy, text, f, fill, stroke=0, stroke_fill=INK):
    d.text(xy, text, font=f, fill=fill, anchor="mm", stroke_width=stroke, stroke_fill=stroke_fill)


# --------------------------------------------------------------------------------------------------------------
# 1. Digimon nuevos (solo villanos) y retratos de las cartas de villano
# --------------------------------------------------------------------------------------------------------------
NUEVOS = {1306: f"{DIMG}/barbamon.jpg", 1307: f"{DIMG}/demon.jpg", 1308: f"{DIMG}/belphemonragemode.jpg",
          1309: f"{DIMG}/mummymon.jpg", 1310: f"{DIMG}/darkknightmon.jpg", 1311: f"{BINGO}/Skull_Satamon.png",
          1312: f"{DIMG}/neodevimon.jpg", 1313: f"{DIMG}/phelesmon.jpg", 1314: f"{DIMG}/mephismon.jpg",
          1315: f"{DIMG}/lucemonsatanmode.jpg"}
RETRATOS = {"soldado_pesadilla_a": f"{DIMG}/ladydevimon.jpg", "soldado_pesadilla_b": f"{BINGO}/Vamdemon.png",
            "lilithmon": f"{DIMG}/lilithmon.jpg", "barbamon": f"{DIMG}/barbamon.jpg", "daemon": f"{DIMG}/demon.jpg",
            "leviamon": f"{DIMG}/leviamon.jpg", "belphemon": f"{DIMG}/belphemonragemode.jpg",
            "beelzemon": f"{DIMG}/beelzebumon.jpg", "lucemon": f"{DIMG}/lucemon.jpg"}


def digimon_art():
    for num, path in NUEVOS.items():
        save(fit(quitar_fondo(path), 320, 320), f"card_generator/pokemon/{num}.png")
    for name, path in RETRATOS.items():
        # Mismo tamaño que los retratos del mod (649×1235), apoyado abajo como un entrenador de cuerpo entero.
        save(fit(quitar_fondo(path), 649, 1235, anchor="bottom"), f"card_generator/trainers/{name}.png")


# --------------------------------------------------------------------------------------------------------------
# 2. Símbolo de la campaña (estrella de 7 puntas = 7 pecados), ícono de villano y reversos
# --------------------------------------------------------------------------------------------------------------
PURPLE, VIOLET, GOLD, RED = (88, 44, 130), (150, 90, 210), (236, 190, 70), (190, 40, 60)


def star7(size, fill=VIOLET, inner=0.45, edge=INK, glow=None):
    s = size * 4
    im = Image.new("RGBA", (s, s), (0, 0, 0, 0))
    d = ImageDraw.Draw(im)
    cx = cy = s / 2

    def pts(R, r):
        out = []
        for i in range(14):
            ang = -math.pi / 2 + i * math.pi / 7
            rad = R if i % 2 == 0 else r
            out.append((cx + rad * math.cos(ang), cy + rad * math.sin(ang)))
        return out
    R = s * 0.48
    d.polygon(pts(R, R * inner), fill=edge)
    d.polygon(pts(R * 0.88, R * inner * 0.86), fill=fill)
    d.ellipse((cx - R * 0.2, cy - R * 0.2, cx + R * 0.2, cy + R * 0.2), fill=edge)
    d.ellipse((cx - R * 0.13, cy - R * 0.13, cx + R * 0.13, cy + R * 0.13), fill=glow or GOLD)
    return im.resize((size, size), Image.LANCZOS)


def card_back(kind, title, numeral):
    W, H = 2084, 3643
    im = Image.new("RGBA", (W, H), INK + (255,))
    d = ImageDraw.Draw(im)
    d.rounded_rectangle((70, 70, W - 70, H - 70), radius=90, outline=(245, 245, 250), width=34)
    # degradado violeta suave en el centro
    grad = Image.new("L", (W, H), 0)
    gd = ImageDraw.Draw(grad)
    for i in range(40):
        r = 1500 - i * 30
        gd.ellipse((W / 2 - r, H / 2 - r, W / 2 + r, H / 2 + r), fill=min(255, 6 + i * 3))
    im.paste(Image.new("RGBA", (W, H), PURPLE + (255,)), mask=grad.filter(ImageFilter.GaussianBlur(60)).point(lambda v: v // 2))
    d = ImageDraw.Draw(im)
    text_center(d, (W / 2, 330), title, font(170, True), (245, 245, 250))
    if numeral:
        text_center(d, (W / 2, 560), numeral, font(200, True), (245, 245, 250))
    st = star7(1250)
    im.alpha_composite(st, ((W - st.width) // 2, 1080))
    text_center(d, (W / 2, 2560), "LA REBELIÓN", font(150, True), (245, 245, 250))
    text_center(d, (W / 2, 2740), "DE LUCEMON", font(150, True), (245, 245, 250))
    text_center(d, (W / 2, 2920), "CAMPAÑA", font(80), (200, 190, 220))
    return im


def campaign_art():
    save(star7(1300), "card_generator/encounter_icons/galactic.png")
    save(card_back("grunt", "RECLUTA", "I"), "card_generator/card_backs/grunt.png")
    save(card_back("commander", "COMANDANTE", "II"), "card_generator/card_backs/commander.png")
    save(card_back("boss", "JEFE", "III"), "card_generator/card_backs/boss.png")


# --------------------------------------------------------------------------------------------------------------
# 3. Fichas de objetos (mismos nombres que el mod)
# --------------------------------------------------------------------------------------------------------------
# Bonguri -> alimentos (economia_alimentos.md): color del mod -> (Twemoji, color de la ficha)
FOOD = {"red": ("1f356", (214, 64, 58)), "yellow": ("1f34c", (236, 190, 50)), "blue": ("1f41f", (60, 120, 210)),
        "pink": ("1f34e", (232, 120, 170)), "green": ("1f34d", (80, 160, 80)), "white": ("1f955", (235, 235, 240)),
        "black": ("1f48a", (60, 60, 70))}
BROWN = (150, 92, 58)


def food_tokens():
    for color, (code, col) in FOOD.items():
        save(icon(code, 780), f"tokens/item_icons/apricorn_{color}.png")
        save(on_disk(844, col, icon(code, 600), scale=0.68), f"tokens/item_tokens/{color}_apricorn.png")
        # Despensa: anillo café con 3 unidades del alimento
        t = disk(785, (205, 150, 105), ring=BROWN)
        one = fit(icon(code, 400), 300, 300)
        for (x, y) in ((0.30, 0.47), (0.56, 0.30), (0.56, 0.60)):
            t.alpha_composite(one, (round(785 * x - 150), round(785 * y - 150)))
        save(t, f"tokens/item_tokens/{color}_apricorn_stash.png")


# Balls -> capturas con Digivice (dibujo propio, no es el Digivice de la serie)
CAPTURE = {"poke_ball": ("Básica", (225, 225, 232)), "greater_ball": ("Mejorada", (70, 130, 215)),
           "ultimate_ball": ("Avanzada", (236, 190, 50)), "keystone_ball": ("Ancestral", (130, 80, 190))}


def device(size, body):
    s = size * 4
    im = Image.new("RGBA", (s, s), (0, 0, 0, 0))
    d = ImageDraw.Draw(im)
    e = round(s * 0.035)
    x0, y0, x1, y1 = s * 0.2, s * 0.14, s * 0.8, s * 0.88
    d.rounded_rectangle((x0 - e, y0 - e, x1 + e, y1 + e), radius=s * 0.16, fill=INK)
    d.rounded_rectangle((x0, y0, x1, y1), radius=s * 0.14, fill=body)
    # pantalla
    d.rounded_rectangle((s * 0.3 - e, s * 0.24 - e, s * 0.7 + e, s * 0.56 + e), radius=s * 0.06, fill=INK)
    d.rounded_rectangle((s * 0.3, s * 0.24, s * 0.7, s * 0.56), radius=s * 0.05, fill=(120, 200, 170))
    d.polygon([(s * 0.36, s * 0.48), (s * 0.5, s * 0.3), (s * 0.64, s * 0.48)], fill=(90, 160, 140))
    # botones
    for bx in (0.37, 0.63):
        d.ellipse((s * bx - s * 0.06 - e, s * 0.7 - s * 0.06 - e, s * bx + s * 0.06 + e, s * 0.7 + s * 0.06 + e), fill=INK)
        d.ellipse((s * bx - s * 0.06, s * 0.7 - s * 0.06, s * bx + s * 0.06, s * 0.7 + s * 0.06), fill=(240, 240, 245))
    return im.resize((size, size), Image.LANCZOS)


def capture_tokens():
    for key, (name, col) in CAPTURE.items():
        dv = device(709, col)
        save(dv, f"tokens/item_icons/{key}.png")
        save(on_disk(785, (245, 245, 248), dv, ring=(80, 170, 90), scale=0.7), f"tokens/poke_ball_tokens/{key}.png")


# Estofados -> comidas (mismo efecto)
MEALS = {"stew_refreshing": "1f372", "stew_alluring": "1f362", "stew_zesty": "1f964", "stew_infused": "1f957"}


def meal_icons():
    for key, code in MEALS.items():
        im = Image.new("RGBA", (1169, 682), (0, 0, 0, 0))
        ic = icon(code, 660, pad=0.04)
        im.alpha_composite(ic, ((1169 - 660) // 2, 11))
        save(im, f"tokens/item_icons/{key}.png")


# Fragmentos -> Emblemas. El mod tiene 3 fragmentos; la campaña 1 usa 6 Emblemas (+1 espacio cada 2).
# Diseños propios: placa con forma de lágrima y un símbolo genérico (no son los emblemas de la serie).
EMBLEMS = {"pureza": ("1f4a7", (120, 200, 240)), "sinceridad": ("1f91d", (110, 180, 110)), "amor": ("2764", (230, 90, 110)),
           "amistad": ("1f30a", (70, 120, 210)), "valor": ("1f525", (240, 140, 50)), "conocimiento": ("1f4d6", (150, 110, 200))}
EXTRA_TW = ["1f4a7", "1f91d", "2764", "1f30a", "1f525", "1f4d6", "1f4a1"]


def tag(size, col):
    s = size * 4
    im = Image.new("RGBA", (s, s), (0, 0, 0, 0))
    d = ImageDraw.Draw(im)
    e = round(s * 0.035)

    def shape(m):
        return [(s * 0.5, s * 0.06 + m), (s * 0.86 - m, s * 0.32), (s * 0.86 - m, s * 0.72), (s * 0.5, s * 0.95 - m),
                (s * 0.14 + m, s * 0.72), (s * 0.14 + m, s * 0.32)]
    d.polygon(shape(0), fill=INK)
    d.polygon(shape(e * 1.6), fill=col)
    d.polygon([(x, y) for (x, y) in shape(e * 1.6)][:3] + [(s * 0.5, s * 0.5)], fill=tuple(min(255, c + 35) for c in col))
    return im.resize((size, size), Image.LANCZOS)


def emblem(size, code, col):
    t = tag(size, col)
    c = icon(code, round(size * 0.5), pad=0.02)
    t.alpha_composite(c, ((size - c.width) // 2, round(size * 0.27)))
    return t


def emblem_tokens():
    for i, (key, (code, col)) in enumerate(EMBLEMS.items()):
        save(emblem(996, code, col), f"tokens/heart_shards/emblema_{key}.png")
    # Los 3 nombres del mod apuntan a los 3 primeros emblemas, para que el TTS siga funcionando sin cambios.
    for old, key in (("emotion_shard", "pureza"), ("knowledge_shard", "conocimiento"), ("willpower_shard", "valor")):
        save(emblem(996, *EMBLEMS[key]), f"tokens/heart_shards/{old}.png")
    # Corazón de Sinnoh -> Emblema de la Luz
    luz = emblem(1992, "1f4a1", (250, 225, 110))
    big = Image.new("RGBA", (2057, 1992), (0, 0, 0, 0)); big.alpha_composite(luz, ((2057 - 1992) // 2, 0))
    save(big, "tokens/item_icons/heart_of_sinnoh.png")
    save(on_disk(785, (60, 55, 90), emblem(600, "1f4a1", (250, 225, 110)), ring=GOLD), "tokens/item_tokens/heart_of_sinnoh.png")


# Esferas de Dialga/Palkia/Giratina -> plumas de los 3 Arcángeles (tinte sobre la pluma de Twemoji)
ANGELS = {"adamant": ("Seraphimon", (245, 205, 90)), "lustrous": ("Ophanimon", (130, 200, 240)),
          "griseous": ("Cherubimon", (190, 120, 220))}


def tint(im, col):
    g = ImageOps.grayscale(im.convert("RGB"))
    t = ImageOps.colorize(g, (40, 30, 50), col)
    t.putalpha(im.split()[3])
    return t


def feather_tokens():
    for key, (angel, col) in ANGELS.items():
        f = outline(tint(twemoji("1fab6", 560), col), 9)
        save(fit(f, 709, 709), f"tokens/item_icons/{key}_orb.png")
        save(on_disk(784, (245, 245, 248), f, ring=col), f"tokens/item_tokens/{key}_artifact.png")


def comandantes_tokens():
    """Fichas de mapa de los villanos (en el mod: grunt, jupiter, mars, saturn, cyrus)."""
    sins = {"grunt": ("soldado_pesadilla_b", (110, 90, 140)), "lilithmon": ("lilithmon", (200, 90, 170)),
            "barbamon": ("barbamon", (220, 180, 60)), "daemon": ("daemon", (210, 70, 60)),
            "leviamon": ("leviamon", (60, 120, 200)), "belphemon": ("belphemon", (100, 150, 110)),
            "beelzemon": ("beelzemon", (150, 70, 160)), "lucemon": ("lucemon", (240, 240, 245))}
    for key, (portrait, col) in sins.items():
        art = quitar_fondo(RETRATOS[portrait])
        t = on_disk(784, col, art, ring=INK, scale=0.72)
        st = star7(170, glow=col)
        t.alpha_composite(st, (784 - 230, 784 - 230))
        save(t, f"tokens/galactic_tokens/{key}.png")
    # los nombres del mod (para no tocar el TTS): grunt/jupiter/mars/saturn/cyrus
    for old, new in (("jupiter", "lilithmon"), ("mars", "daemon"), ("saturn", "leviamon"), ("cyrus", "lucemon")):
        Image.open(os.path.join(OUT, f"tokens/galactic_tokens/{new}.png")).save(os.path.join(OUT, f"tokens/galactic_tokens/{old}.png"))


if __name__ == "__main__":
    digimon_art()
    campaign_art()
    food_tokens()
    capture_tokens()
    meal_icons()
    emblem_tokens()
    feather_tokens()
    comandantes_tokens()
    n = sum(len(f) for _, _, f in os.walk(OUT))
    print("archivos:", n)
