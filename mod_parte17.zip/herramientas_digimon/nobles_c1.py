"""Formas Nobles Digimon (equivalen a las 18 Formas Nobles del mod).

Como en el mod, una Forma Noble es el REVERSO (estado 2 en Tabletop Simulator) de una carta Fuerte:
  - la carta base pasa a estado 1 y la Forma Noble va en la fila siguiente, con estado 2 y la misma cantidad de copias;
  - mismos stats que la base, +2 de iniciativa y +2 de vida (i_mod/h_mod), clima "Noble", sin bioma, nivel legendario;
  - un ataque más fuerte, con el mismo efecto que el ataque de la Forma Noble del mod que reemplaza.

Como hay que insertar filas en medio de la hoja, el script reescribe todas las fórmulas de la hoja pokemon con los
números de fila nuevos (y amplía a 1000 filas los rangos de la hoja moves que miran a pokemon).
Volver a correrlo primero quita las Formas Nobles anteriores.

Uso: python nobles_c1.py sinnoh_cube.xlsx    (después abrir y guardar en Excel/LibreOffice para recalcular)
"""
import re
import sys

import openpyxl
from openpyxl.worksheet.formula import ArrayFormula

CUBE = sys.argv[1] if len(sys.argv) > 1 else "sinnoh_cube.xlsx"

H = "Durante este ataque y cuando el usuario sea atacado nuevamente, los símbolos de estado infligen +1 de daño."
F = "Inflige el estado Confuso al usuario. El daño que reciba el usuario durante este ataque también se aplica al objetivo."
# Digimon base: (ataque, potencia, efecto)   — entre paréntesis, la Forma Noble del mod de la que sale el efecto
NOBLES = {
    "Wargreymon": ("Fuerza Gaia Suprema", 100, H),                                                   # Torterra
    "MetalGarurumon": ("Lobo Glacial Supremo", 110,
                       "Inflige el estado Congelado al objetivo. Los símbolos de estado infligen -1 de daño."),  # Walrein
    "Phoenixmon": ("Llama del Fénix", 110,
                   "Inflige el estado Quemado al objetivo. Los símbolos de estado infligen -1 de daño."),       # Chandelure
    "HerculesKabuterimon": ("Giga Explosión", 100,
                            "Si se obtienen 2 o más símbolos de estado: Inflige el estado Paralizado al objetivo."),  # Raichu
    "Rosemon": ("Tifón de Pétalos", 100, F),                                                          # Roserade
    "Vikemon": ("Mjölnir", 100, "Si se obtienen 2 o más símbolos de estado: Inflige 2 de daño a un Digimon del "
                                "equipo del objetivo que no sea el objetivo."),                        # Mamoswine
    "MetalSeadramon": ("Corriente Definitiva", 100, "Los golpes críticos infligen +2 de daño, pero por cada golpe "
                                                    "crítico obtenido: El usuario recibe 2 de daño."),  # Empoleon
    "SaberLeomon": ("Colmillo Infinito", 100, H),                                                     # Staraptor
    "Ravemon": ("Ala del Cuervo Celeste", 75, "Los golpes críticos infligen +1 de daño."),            # Togekiss
    "MegaGargomon": ("Fuego Gargo Total", 120,
                     "Si este ataque se usó el turno anterior, su fuerza de ataque baja a 2."),       # Porygon-Z
    "Sakuyamon": ("Sello Espiritual", 80, "Aumenta la fatiga de batalla del objetivo en 2. El objetivo ya no puede "
                                          "cambiar o huir del combate."),                              # Decidueye
    "Triceramon": ("Embestida Tricornio", 100,
                   "Los golpes críticos infligen +1 de daño, pero los símbolos de estado infligen -1 de daño."),  # Samurott
    "Diaboromon": ("Destructor de la Red", 100, F),                                                   # Infernape
    "VenomMyotismon": ("Infierno Venenoso", 80, "Los símbolos de estado infligen +1 de daño."),       # Naganadel
    "HiAndromon": ("Rayo Atómico Total", 85,
                   "Si el usuario conoce otro ataque de elemento Eléctrico, inflige 2 de daño adicional."),  # Luxray
    "GranKuwagamon": ("Tijera del Fin", "?", "La fuerza de ataque es igual a la mitad de la vida base del objetivo, "
                                             "redondeada hacia abajo. Máximo 7 de fuerza de ataque."),   # Machamp
    "Lotusmon": ("Ataduras de la Serpiente", "?",
                 "La fuerza de ataque es igual a la vida actual del usuario. Máximo 7 de fuerza de ataque."),  # Typhlosion
    "Plesiomon": ("Canción del Mar Helado", 75,
                  "Si se obtiene algún símbolo de estado: Inflige el estado Congelado al objetivo."),  # Dusknoir
}

C = dict(num=1, name=2, biome=13, climate=14, imod=17, hmod=18, evo=26, desc=29, mname=30, legend=35, tier=36,
         trainer=37, ndeck=38, state=40, elem=42)
REF = re.compile(r"(?<![A-Za-z_!$])(\$?)([A-Z]{1,3})(\$?)(\d+)(?![\d(A-Za-z_])")


def text(v):
    return v.text if isinstance(v, ArrayFormula) else v


def remap(formula, m):
    def sub(mt):
        r = int(mt.group(4))
        return f"{mt.group(1)}{mt.group(2)}{mt.group(3)}{m.get(r, r)}"
    return REF.sub(sub, formula)


def main():
    wb = openpyxl.load_workbook(CUBE)
    ws, mv = wb["pokemon"], wb["moves"]
    ncol = ws.max_column
    last = max(r for r in range(2, ws.max_row + 1) if ws.cell(r, C["name"]).value)
    rows = {r: [ws.cell(r, c).value for c in range(1, ncol + 1)] for r in range(2, last + 1)}

    # 1) quitar Formas Nobles de una corrida anterior (y volver la base a estado 0)
    order = []
    for r in range(2, last + 1):
        v = rows[r]
        if v[C["climate"] - 1] == "Noble":
            if order:
                rows[order[-1]][C["state"] - 1] = 0
            continue
        order.append(r)

    # 2) nuevo orden: cada Forma Noble va justo después de su carta base
    base_row = {}
    for r in order:
        n = rows[r][C["name"] - 1]
        if n in NOBLES and not rows[r][C["trainer"] - 1] and rows[r][C["tier"] - 1] != "legendary":
            base_row.setdefault(n, r)
    missing = set(NOBLES) - set(base_row)
    if missing:
        raise SystemExit(f"No están en el cube: {missing}")
    plan = []  # (fila vieja, es_noble)
    for r in order:
        plan.append((r, False))
        if base_row.get(rows[r][C["name"] - 1]) == r:
            plan.append((r, True))
    newpos = {}
    for i, (r, noble) in enumerate(plan, start=2):
        if not noble:
            newpos[r] = i
    newpos[last + 1] = len(plan) + 2  # referencias a "la fila siguiente" de la última

    # 3) ataques nuevos
    have = {mv.cell(r, 1).value: r for r in range(2, mv.max_row + 1) if mv.cell(r, 1).value}
    tmpl = max(have.values())
    for name, (move, power, effect) in NOBLES.items():
        r = have.get(move) or max(have.values()) + 1
        have[move] = r
        elem = rows[base_row[name]][C["elem"] - 1]
        mv.cell(r, 1, move); mv.cell(r, 2, elem); mv.cell(r, 3, power); mv.cell(r, 5, effect)
        mv.cell(r, 4, f'=IF(NOT(ISBLANK(C{r})), IF(ISNUMBER(C{r}), ROUND((C{r} - 5)/20, 0), C{r}), "")')
        for c in (6, 7, 8):
            src = text(mv.cell(tmpl, c).value)
            mv.cell(r, c).value = ArrayFormula(mv.cell(r, c).coordinate, src.replace(f"$A{tmpl}", f"$A{r}"))
        mv.cell(r, 9, f"=H{r}-G{r}")
    # rangos de moves que miran a pokemon: hasta la fila 1000, y que no cuenten las Formas Nobles
    for r in range(2, mv.max_row + 1):
        for c in (6, 7, 8):
            v = mv.cell(r, c).value
            t = text(v)
            if isinstance(t, str) and "pokemon!" in t:
                t = re.sub(r"(pokemon!\$[A-Z]+\$\d+:\$[A-Z]+\$)\d+", r"\g<1>1000", t)
                t = t.replace('<> "Noble Form")', '<> "Noble Form")*(pokemon!$AC$2:$AC$1000 <> "Forma Noble")') \
                    if "Forma Noble" not in t else t
                mv.cell(r, c).value = ArrayFormula(v.ref if isinstance(v, ArrayFormula) else mv.cell(r, c).coordinate, t)

    # 4) reescribir la hoja
    for r in range(2, ws.max_row + 1):
        for c in range(1, ncol + 1):
            ws.cell(r, c).value = None
    for i, (r, noble) in enumerate(plan, start=2):
        v = list(rows[r])
        m = dict(newpos)
        if noble:
            m[r] = i  # la copia mira a su propia fila
            name = v[C["name"] - 1]
            move = NOBLES[name][0]
            v[C["num"] - 1] = f"{v[C['num'] - 1]}-n"
            v[C["biome"] - 1] = None
            v[C["climate"] - 1] = "Noble"
            v[C["imod"] - 1] = (v[C["imod"] - 1] or 0) + 2
            v[C["hmod"] - 1] = (v[C["hmod"] - 1] or 0) + 2
            v[C["evo"] - 1] = None
            v[C["desc"] - 1] = "Forma Noble"
            v[C["mname"] - 1] = move
            v[C["legend"] - 1] = 1
            v[C["tier"] - 1] = "legendary"
            v[C["state"] - 1] = 2
        elif rows[r][C["name"] - 1] in NOBLES and base_row.get(rows[r][C["name"] - 1]) == r:
            v[C["state"] - 1] = 1
        for c, val in enumerate(v, start=1):
            if isinstance(val, ArrayFormula):
                val = ArrayFormula(ws.cell(i, c).coordinate, remap(val.text, m))
            elif isinstance(val, str) and val.startswith("="):
                val = remap(val, m)
            ws.cell(i, c).value = val
    wb.save(CUBE)
    print(f"Formas Nobles: {len(NOBLES)}. Filas: {last} -> {len(plan) + 1}.")


if __name__ == "__main__":
    main()
