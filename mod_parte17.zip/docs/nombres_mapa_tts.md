# Campaña 1 · Nombres del mapa para Tabletop Simulator

Las imágenes ya están cambiadas en la carpeta del mod. Los **nombres** que se ven en la mesa (por ejemplo, en el botón de volar de cada pueblo) son el campo *Name* de cada objeto, que está en la partida guardada de TTS y no en esta carpeta. Para cambiarlos, haz clic derecho en el objeto → *Name* y escribe el nombre nuevo.

## Pueblos (fichas hexagonales y cartas de pueblo)

| Objeto en la mesa | Nombre nuevo | Color | Iniciales |
|---|---|---|---|
| Stark Village | Ciudad Factorial | Rojo | Agumon, Guilmon |
| Snowpoint Village | Aldea Freezeland | Blanco | Gabumon, Gaomon |
| Sunyshore Village | Playa de Coral | Amarillo | Terriermon, Veemon |
| Nesburgh Village | Ciudad del Comienzo | Naranjo | Shoutmon, Gumdramon |
| Celestic Village | Tierra de Escarabajos | Verde | Palmon, Wormmon |
| Canalave Village | Castillo Geko | Azul | Gomamon |
| Eterna Village | Pueblo Juguete | Morado | Renamon, Coronamon |
| Sinnome Village | Aldea Yokomon | Rosado | Patamon, Biyomon |

## Santuarios y lugares legendarios

| Objeto en la mesa | Nombre nuevo | Legendario que aparece |
|---|---|---|
| Frostsong Shrine | Santuario Canto Helado | Goddramon |
| Thundersong Shrine | Santuario Canto Trueno | Holydramon |
| Firesong Shrine | Santuario Canto Fuego | Megidramon |
| Timeless Shrine | Santuario Atemporal | Omegamon |
| Moonglade Shrine | Santuario Claro Lunar | Duftmon / Craniummon |
| Colossus Shrine | Santuario del Coloso | Huanglongmon |
| Origin Shrine | Altar de Yggdrasil | Los tres Arcángeles |
| Garden of Gratitude | Jardín Real | Dukemon |
| Grand Chateau | Fortaleza Imperial | Imperialdramon |
| Hallowed Tower | Torre Sagrada | Alphamon |
| Magma Chamber | Nido del Dragón | Examon |
| Temple of the Sea | Templo de los Milagros | Magnamon |

## Puertas de los Pecados (Acto II) y Puerta de Cocytus (Acto III)

El mod tiene 3 lagos y la campaña usa 6 puertas. Las fichas de los 3 lagos ya muestran 3 puertas; las otras 3 hay que agregarlas: copia una ficha de lago (Ctrl+C / Ctrl+V), clic derecho → *Custom* y cambia la imagen por la de su puerta.

| Objeto | Nombre nuevo | Imagen | Señor Demonio |
|---|---|---|---|
| Lake Acuity | Puerta de la Lujuria | lake_acuity.png (= puerta_lujuria.png) | Lilithmon |
| Lake Verity | Puerta de la Codicia | lake_verity.png (= puerta_codicia.png) | Barbamon |
| Lake Valor | Puerta de la Ira | lake_valor.png (= puerta_ira.png) | Daemon |
| (nueva) | Puerta de la Envidia | puerta_envidia.png | Leviamon |
| (nueva) | Puerta de la Pereza | puerta_pereza.png | Belphemon |
| (nueva) | Puerta de la Gula | puerta_gula.png | Beelzemon |
| Temple of Sinnoh | Puerta de Cocytus | temple_of_sinnoh.png | Lucemon |

Dónde poner cada puerta: ver `mapa_mundo_digital.png` (cada puerta está en la zona de su bioma y clima).

## Zonas del mapa

El tablero mantiene los mismos hexágonos (así siguen existiendo las 12 combinaciones de bioma y clima que piden las cartas). Las zonas tienen nombre del Mundo Digital: Freezeland, Pantano Brumoso, Monte Infinito, Montaña Basura, Gran Cañón, Fosa Abisal, Sabana del Engranaje, Bosque Nativo, Tierra de los Escarabajos, Desierto de Datos, Mar del Norte, Mar Cálido del Server, etc.
