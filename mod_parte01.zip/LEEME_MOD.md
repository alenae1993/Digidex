# Leyendas Digimon · mod de Tabletop Simulator (campaña 1: La rebelión de Lucemon)

Estos zip traen **solo los archivos que cambian** respecto del mod original "Pokémon: Legends of Sinnoh" (pokemon-legends-master).
Para armar el juego: descomprime todos los `mod_parte*.zip` **encima** de la carpeta `pokemon-legends-master` (acepta reemplazar).

| Carpeta | Qué trae |
|---|---|
| `sinnoh_cube.xlsx` | 376 Digimon, 46 cartas de villano, 28 legendarios, 18 Formas Nobles, digievoluciones |
| `card_generator/` | generador con los ajustes Digimon (nombres largos y formas en español) |
| `assets/card_generator/` | ilustraciones de las cartas, retratos de villanos, reversos, objetos de forma |
| `assets/cards/` | cartas de Acto, Cambio de Destino, Santuario y Pueblo en español |
| `assets/tokens/` | alimentos, capturas, comidas, emblemas, plumas, villanos, legendarios, artefactos, objetos de batalla, aldeas, puertas, recolección |
| `assets/bases/` | mapa del Mundo Digital y tablero de la campaña |
| `herramientas_digimon/` | los scripts que generan todo lo anterior |
| `docs/` | las 7 campañas, la economía de alimentos, el póster del mapa y los nombres para cambiar en TTS |

Las 2 hojas más grandes (cartas de pueblo y de santuario) vienen partidas en dos; después de descomprimir corre `python herramientas_digimon/unir_hojas.py .` desde la carpeta del mod para unirlas.

Después: cierra el cube en Excel, borra `card_generator/output` y corre el generador (`generate_moves.py`, `generate_pokemon.py`).
En Tabletop Simulator hay que cambiar a mano los nombres de los objetos (ver `docs/nombres_mapa_tts.md`).
